import java.util.Scanner;

public class Q1 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int T = sc.nextInt();  // Read number of test cases
        for (int i = 0; i < T; i++) {
            int N = sc.nextInt();  // Read each number
            if (N % 3 == 0) {
                System.out.println(0 + " " + (N / 3));
            } else if (N % 3 == 1) {
                System.out.println(2 + " " + (N / 3 - 1));
            } else {
                System.out.println(1 + " " + (N / 3));
            }
        }
        
        sc.close();  // Close the scanner
    }
}