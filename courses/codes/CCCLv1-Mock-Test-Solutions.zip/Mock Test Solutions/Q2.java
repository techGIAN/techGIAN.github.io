import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Q2 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int M = sc.nextInt();  // Read M
        int N = sc.nextInt();  // Read N
        sc.nextLine();  // To consume the newline character after reading integers

        String[] coordInput = sc.nextLine().split(" ");  // Read initial coordinates
        int[] coordinates = new int[2];
        coordinates[0] = Integer.parseInt(coordInput[0]);
        coordinates[1] = Integer.parseInt(coordInput[1]);

        int[] currSpot = {0, 0};  // Starting point (0, 0)
        List<String> movements = new ArrayList<>();  // List to store movements

        while (coordinates[0] != M || coordinates[1] != N) {
            if (currSpot[0] == coordinates[0] && currSpot[1] + 1 == coordinates[1]) {
                movements.add("U");
            } else if (currSpot[0] == coordinates[0] && currSpot[1] - 1 == coordinates[1]) {
                movements.add("D");
            } else if (currSpot[0] + 1 == coordinates[0] && currSpot[1] == coordinates[1]) {
                movements.add("R");
            } else {
                movements.add("L");
            }

            // Update the current position and read the next coordinates
            currSpot[0] = coordinates[0];
            currSpot[1] = coordinates[1];

            // Read new coordinates
            coordInput = sc.nextLine().split(" ");
            coordinates[0] = Integer.parseInt(coordInput[0]);
            coordinates[1] = Integer.parseInt(coordInput[1]);
        }

        // After exiting the loop, perform one final movement
        if (currSpot[0] == coordinates[0] && currSpot[1] + 1 == coordinates[1]) {
            movements.add("U");
        } else if (currSpot[0] == coordinates[0] && currSpot[1] - 1 == coordinates[1]) {
            movements.add("D");
        } else if (currSpot[0] + 1 == coordinates[0] && currSpot[1] == coordinates[1]) {
            movements.add("R");
        } else {
            movements.add("L");
        }

        // Print the movements
        System.out.println(String.join(" ", movements));
        
        sc.close();
    }
}