T = int(input())
for _ in range(T):
    N = int(input())
    if N % 3 == 0:
        print(0, N // 3)
    elif N % 3 == 1:
        print(2, N // 3 - 1)
    else:
        print(1, N // 3)