M = int(input())
N = int(input())
coordinates = [int(x) for x in input().split()]
curr_spot = [0,0]
movements = []
while coordinates[0] != M or coordinates[1] != N:
    if curr_spot[0] == coordinates[0] and curr_spot[1] + 1 == coordinates[1]:
        movements.append("U")
    elif curr_spot[0] == coordinates[0] and curr_spot[1] - 1 == coordinates[1]:
        movements.append("D")
    elif curr_spot[0] + 1 == coordinates[0] and curr_spot[1] == coordinates[1]:
        movements.append("R")
    else:
        movements.append("L")
    curr_spot = coordinates
    coordinates = [int(x) for x in input().split()]

# do it one more time to get the last character
if curr_spot[0] == coordinates[0] and curr_spot[1] + 1 == coordinates[1]:
    movements.append("U")
elif curr_spot[0] == coordinates[0] and curr_spot[1] - 1 == coordinates[1]:
    movements.append("D")
elif curr_spot[0] + 1 == coordinates[0] and curr_spot[1] == coordinates[1]:
    movements.append("R")
else:
    movements.append("L")
print(' '.join(movements))