class Car:

    def __init__(self, fuel=100, brand='Ford', headlights=False, color='black', engine=False, license_plate=''):
        self.fuel = fuel
        self.brand = brand
        self.headlights = headlights
        self.color = color
        self.engine = engine
        self.license_plate = license_plate

    def get_fuel(self):
        return self.fuel

    def get_brand(self):
        return self.brand

    def get_headlights(self):
        return self.headlights

    def get_color(self):
        return self.color

    def get_engine(self):
        return self.engine

    def get_license_plate(self):
        return self.license_plate

    def set_fuel(self, fuel):
        self.fuel = fuel

    def set_brand(self, brand):
        self.brand = brand

    def switch_headlights(self):
        self.headlights = not self.headlights

    def set_color(self, color):
        self.color = color

    def set_engine(self, engine):
        self.engine = engine

    def set_license_plate(self, license_plate):
        self.license_plate = license_plate

    @staticmethod
    def honk(x):
        for _ in range(x):
            print('Honk!')

# c = Car()

