from car import Car

# c = Car()
# # print(c.get_fuel()) # 100
# # c.set_fuel(90)
# # print(c.get_fuel()) # 90
# #
# # c.set_brand('Subaru')
# # print(c.get_brand()) # Subaru
# #
# # c.switch_headlights()
# # print(c.get_headlights()) # True
# #
# # print(c.get_color())
# # c.set_color('blue')
# # print(c.get_color())
# #
# # c.set_engine(True)
# # print(c.get_engine())
#
# c2 = Car(brand='Honda', color='white')
# print(c.get_brand())
# print(c2.get_brand())
# print(c2.get_color())

Car.honk(5)