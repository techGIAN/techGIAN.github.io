import java.util.Locale;

public class Light {
    public static String RED = "red";
    public static String BLUE = "blue";
    public static String GREEN = "green";
    public static String WHITE = "white";

    boolean burntOut;
    boolean on;
    String color;

    public Light() {
        /*
            to-do
        */
    }

    public Light(boolean o, boolean b, String c) {
        /*
            to-do
        */
    }

    public void burnOut() {
        /*
            to-do
        */
    }

    public void flip() {
        /*
            to-do
        */
    }

    public String getColor() {
        /*
            to-do
        */
    }

    public void setColor(String c) {
        /*
            to-do
        */
    }

    public boolean isOn() {
        /*
            to-do
        */
    }

    @Override
    public String toString() {
        /*
            to-do
        */
    }
}


