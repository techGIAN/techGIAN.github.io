class Light:
    RED = "red"
    BLUE = "blue"
    GREEN = "green"
    WHITE = "white"

    def __init__(self, o=True, b=False, c=WHITE):
        '''
            to-do
        '''

    def __str__(self):
        '''
            to-do
        '''

    def burn_out(self):
        '''
            to-do
        '''

    def flip(self):
        '''
            to-do
        '''

    def get_color(self):
        '''
            to-do
        '''

    def set_color(self, c):
        '''
            to-do
        '''

    def is_on(self):
        '''
            to-do
        '''

