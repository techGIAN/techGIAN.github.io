#include <iostream>
#include <vector>

using namespace std;

class Node {
public:
    int val;
    Node* next;

    Node(int val=0, Node* nxt=nullptr) : val(val), next(nxt) {}

    string toString() {
        return "[" + to_string(val) + "] ";
    }
};

class LinkedListInteger {
private:
    Node* head;
    int size;

public:
    LinkedListInteger() : head(nullptr), size(0) {}

    LinkedListInteger(vector<int> nums) : head(nullptr), size(0) {
        for (int num : nums) {
            Node* n = new Node(num);
            insertAtTail(n);
        }
        size = nums.size();
    }

    int getSize() {
        return size;
    }

    Node* getHead() {
        return head;
    }

    void insertAtHead(Node* n) {
        n->next = head;
        head = n;
        size++;
    }

    void insertAtTail(Node* n) {
        if (size > 0) {
            Node* temp = head;
            while (temp->next) {
                temp = temp->next;
            }
            temp->next = n;
        } else {
            head = n;
        }
        size++;
    }

    int removeHead() {
        int value = head->val;
        head = head->next;
        size--;
        return value;
    }

    int removeTail() {
        int value;
        if (size == 1) {
            value = head->val;
            head = nullptr;
        } else {
            Node* temp = head;
            while (temp->next->next) {
                temp = temp->next;
            }
            value = temp->next->val;
            temp->next = nullptr;
        }
        size--;
        return value;
    }

    LinkedListInteger concatList(LinkedListInteger& other) {
        Node* temp = head;
        while (temp->next) {
            temp = temp->next;
        }
        temp->next = other.getHead();
        return *this;
    }

    LinkedListInteger intertwineList(LinkedListInteger& other) {
        LinkedListInteger result;
        LinkedListInteger* longList = (size >= other.getSize()) ? this : &other;
        LinkedListInteger* shortList = (size < other.getSize()) ? this : &other;
        Node* tempLong = longList->getHead();
        Node* tempShort = shortList->getHead();
        while (tempLong && tempShort) {
            result.insertAtTail(new Node(tempLong->val));
            result.insertAtTail(new Node(tempShort->val));
            tempLong = tempLong->next;
            tempShort = tempShort->next;
        }
        if (tempLong) {
            result.insertAtTail(new Node(tempLong->val));
        }
        head = result.getHead();
        size = result.getSize();
        return result;
    }

    string toString() {
        string stringRepresentation = "";
        Node* temp = head;
        while (temp) {
            stringRepresentation += temp->toString() + "-> ";
            temp = temp->next;
        }
        stringRepresentation += "null";
        return stringRepresentation;
    }
};

int main() {
    Node* n1 = new Node(9);
    Node* n2 = new Node(-4);
    Node* n3 = new Node(2);
    Node* n4 = new Node(-3);
    Node* n5 = new Node(-5);

    LinkedListInteger lst;
    lst.insertAtTail(n2);
    lst.insertAtTail(n3);
    lst.insertAtTail(n4);
    lst.insertAtTail(n5);
    lst.insertAtHead(n1);

    cout << lst.toString() << endl;
    lst.removeTail();
    cout << lst.toString() << endl;
    lst.removeHead();
    cout << lst.toString() << endl;

    LinkedListInteger lst2({7, -1, 3, 8});
    cout << lst2.toString() << endl;

    LinkedListInteger newList = lst.concatList(lst2);
    cout << newList.toString() << endl;
    newList = lst.intertwineList(lst2);
    cout << newList.toString() << endl;

    return 0;
}
