
public class LinkedListIntegerClient {

	static class Node {
		
		// fields of a Node
		private int val;
		private Node next;
		
		/*
		 * Default constructor 1: default value is 0, default next is null
		 */
		public Node() {
			this(0);
		}
		
		/*
		 * Default constructor 2: default next is null
		 */
		public Node(int v) {
			this(v, null);
		}
		
		/*
		 * We create another constructor that takes in the next node as parameter
		 */
		public Node(int v, Node nxt) {
			this.val = v;
			this.next = nxt;
		}
		
		@Override
		public String toString() {
			return "[" + this.val + "] ";
		}
		
	}
	
	static class LinkedListInteger {
		
		// fields of a LinkedListInteger
		private Node head;
		private int size;
		
		public LinkedListInteger() {
			this.head = null;
			this.size = 0;
//			this(new int[0]);		// alternative
		}
		
		public LinkedListInteger(int[] nums) {
			this.head = null;
			for (int num : nums) {
				Node n = new Node(num);
				this.insertAtTail(n);
			}
			this.size = nums.length;
		}
		
		public int getSize() {
			return this.size;
		}
		
		public Node getHead() {
			return this.head;
		}
		
		public void insertAtHead(Node n) {
			n.next = this.head;
			head = n;
			this.size++;
		}
		
		public void insertAtTail(Node n) {
			if (this.size > 0) {
				Node temp = head;
				while (temp.next != null) {
					temp = temp.next;
				}
				temp.next = n;
			} else {
				this.head = n;
			}
			this.size++;
		}
		
		public int removeHead() {
			int value = this.head.val;
			this.head = this.head.next;
			this.size--;
			return value;
		}
		
		public int removeTail() {
			int value;
			if (this.size == 1) {
				value = this.head.val;
				this.head = null;
				return value;
			} else {
				Node temp = this.head;
				while (temp.next.next != null) {
					temp = temp.next;
				}
				value = temp.next.val;
				temp.next = null;
			}
			this.size--;
			return value;
		}
		
		public LinkedListInteger concatList(LinkedListInteger other) {
			Node temp = this.head;
			while (temp.next != null) {
				temp = temp.next;
			}
			temp.next = other.head;
			return this;
		}
		
		/*
		 * Intertwine as follows:
		 * The first item should be from the longer list
		 * If both lists have the same size then start from the this list
		 * Both lists will have a size difference of at most one
		 */
		public LinkedListInteger intertwineList(LinkedListInteger other) {
			
			LinkedListInteger result = new LinkedListInteger();
			LinkedListInteger longList = (this.size >= other.size) ? this : other;
			LinkedListInteger shortList = (this.size < other.size) ? this : other;
			
			Node tempLong = longList.head;
			Node tempShort = shortList.head;
			while (tempLong != null && tempShort != null) {
				result.insertAtTail(new Node(tempLong.val));
				result.insertAtTail(new Node(tempShort.val));
				tempLong = tempLong.next;
				tempShort = tempShort.next;
			}
			if (tempLong != null) {
				result.insertAtTail(new Node(tempLong.val));
			}
			
			this.head = result.head;
			this.size = result.size;
			return result;
		}
		
		@Override
		public String toString() {
			String stringRepresentation = "";
			Node temp = this.head;
			while (temp != null) {
				stringRepresentation += temp.toString() + "-> ";
				temp = temp.next;
			}
			stringRepresentation += "null";
			return stringRepresentation;	
		}
		
		
	}
	
	// Client program
	public static void main(String[] args) {
		Node n1 = new Node(9);
		Node n2 = new Node(-4);
		Node n3 = new Node(2);
		Node n4 = new Node(-3);
		Node n5 = new Node(-5);
		
		LinkedListInteger lst = new LinkedListInteger();
		lst.insertAtTail(n2);
		lst.insertAtTail(n3);
		lst.insertAtTail(n4);
		lst.insertAtTail(n5);
		lst.insertAtHead(n1);
		
		System.out.println(lst.toString());
		
		lst.removeTail();
		System.out.println(lst.toString());
		
		lst.removeHead();
		System.out.println(lst.toString());
		
		// create another list:
		LinkedListInteger lst2 = new LinkedListInteger(new int[] {7, -1, 3, 8});
		System.out.println(lst2.toString());
		
		LinkedListInteger newList = lst.concatList(lst2);
		System.out.println(newList.toString());
		newList = lst.intertwineList(lst2);
		System.out.println(newList.toString());
	}

}
