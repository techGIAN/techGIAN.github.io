#include <iostream>

using namespace std;

class Node {
public:
    int val;
    Node* next;

    Node(int v = 0, Node* nxt = nullptr) : val(v), next(nxt) {}

    ~Node() {
        delete next;
    }

    void print() {
        cout << "[" << val << "] ";
        if (next) {
            next->print();
        }
    }
};

class LinkedListInteger {
private:
    Node* head;
    int size;

public:
    LinkedListInteger() : head(nullptr), size(0) {}

    ~LinkedListInteger() {
        delete head;
    }

    void insert(int x) {
        Node* node = new Node(x);
        if (!head || x <= head->val) {
            node->next = head;
            head = node;
        } else {
            Node* prev = nullptr;
            Node* curr = head;
            while (curr && x > curr->val) {
                prev = curr;
                curr = curr->next;
            }
            prev->next = node;
            node->next = curr;
        }
        size++;
    }

    int remove(int x) {
        if (!head) return 0;
        if (head->val == x) {
            Node* temp = head;
            head = head->next;
            temp->next = nullptr;
            delete temp;
            size--;
            return x;
        } else {
            Node* prev = nullptr;
            Node* curr = head;
            while (curr && curr->val != x) {
                prev = curr;
                curr = curr->next;
            }
            if (curr) {
                prev->next = curr->next;
                curr->next = nullptr;
                delete curr;
                size--;
                return x;
            } else {
                return 0;
            }
        }
    }

    LinkedListInteger mergeList(LinkedListInteger& other) {
        LinkedListInteger result;
        Node* temp1 = head;
        Node* temp2 = other.head;
        while (temp1 && temp2) {
            if (temp1->val <= temp2->val) {
                result.insert(temp1->val);
                temp1 = temp1->next;
            } else {
                result.insert(temp2->val);
                temp2 = temp2->next;
            }
        }
        while (temp1) {
            result.insert(temp1->val);
            temp1 = temp1->next;
        }
        while (temp2) {
            result.insert(temp2->val);
            temp2 = temp2->next;
        }
        return result;
    }

    void print() {
        if (head) {
            head->print();
        }
        cout << "null";
    }
};

int main() {
    LinkedListInteger lst;
    lst.insert(9);
    lst.insert(-4);
    lst.insert(2);
    lst.insert(-3);
    lst.insert(-5);
    lst.print();
    cout << endl;

    LinkedListInteger lst2;
    lst2.insert(7);
    lst2.insert(-1);
    lst2.insert(3);
    lst2.insert(8);
    lst2.print();
    cout << endl;

    LinkedListInteger newList = lst.mergeList(lst2);
    newList.print();
    cout << endl;

    return 0;
}
