public class LinkedListIntegerClientVer2 {

	static class Node {
		
		// fields of a Node
		private int val;
		private Node next;
		
		/*
		 * Default constructor 1: default value is 0, default next is null
		 */
		public Node() {
			this(0);
		}
		
		/*
		 * Default constructor 2: default next is null
		 */
		public Node(int v) {
			this(v, null);
		}
		
		/*
		 * We create another constructor that takes in the next node as parameter
		 */
		public Node(int v, Node nxt) {
			this.val = v;
			this.next = nxt;
		}
		
		@Override
		public String toString() {
			return "[" + this.val + "] ";
		}
		
	}
	
	static class LinkedListInteger {
		
		// fields of a LinkedListInteger
		private Node head;
		private int size;
		
		public LinkedListInteger() {
			this.head = null;
			this.size = 0;
//			this(new int[0]);		// alternative
		}
		
		public LinkedListInteger(int[] nums) {
			this.head = null;
			for (int num : nums) {
				Node n = new Node(num);
				this.insert(n);
			}
			this.size = nums.length;
		}
		
		public int getSize() {
			return this.size;
		}
		
		public Node getHead() {
			return this.head;
		}
		
		public void insert(int x) {
			Node node = new Node(x);
			this.insert(node);
		}
		
		public void insert(Node n) {
			
			boolean nodeInserted = false;
			if (this.size == 0) {
				head = n;
			} else {
				
				Node prev = null;
				Node curr = this.head;
				
				while (curr != null) {
					// found the spot for Node n
					if (n.val <= curr.val) {
						
						n.next = curr;
						
						// n must be at the head
						if (prev == null) {
							this.head = n;
						} else {		// n not a head
							prev.next = n;
						}
						
						nodeInserted = true;
						break;
					}
					prev = curr;
					curr = curr.next;
				}
				
				// means it is inserted in the end
				if (!nodeInserted) {
					prev.next = n;
				}
				
			}
			
			this.size++;
			
		}
		
		public int remove(int x) {
			Node prev = null;
			Node curr = this.head;
			while (curr != null && curr.val != x) {
				prev = curr;
				curr = curr.next;
			}
			if (prev != null) {
				prev.next = curr.next;
			} else {
				this.head = curr.next;
				curr = null;
			}
			this.size--;
			return x;
		}
		
		
		/*
		 * Merge 2 lists to maintain a sorted list
		 * Because both lists are sorted already thanks to how we insert nodes
		 * then maintaining the natural ordering for the merge is easy.
		 */
		public LinkedListInteger mergeList(LinkedListInteger other) {
			
			LinkedListInteger result = new LinkedListInteger();
			
			Node temp1 = this.head;
			Node temp2 = other.head;
			while (temp1 != null && temp2 != null) {
				if (temp1.val >= temp2.val) {
					result.insert(temp2.val);
					temp2 = temp2.next;
				} else {
					result.insert(temp1.val);
					temp1 = temp1.next;
				}
			}
			while (temp1 != null) {
				result.insert(temp1.val);
				temp1 = temp1.next;
			}
			while (temp2 != null) {
				result.insert(temp2.val);
				temp2 = temp2.next;
			}
			
			this.head = result.head;
			this.size = result.size;
			return result;
		}
		
		@Override
		public String toString() {
			String stringRepresentation = "";
			Node temp = this.head;
			while (temp != null) {
				stringRepresentation += temp.toString() + "-> ";
				temp = temp.next;
			}
			stringRepresentation += "null";
			return stringRepresentation;	
		}
		
		
	}
	
	// Client program
	public static void main(String[] args) {
		
		LinkedListInteger lst = new LinkedListInteger();
		lst.insert(9);
		lst.insert(-4);
		lst.insert(2);
		lst.insert(-3);
		lst.insert(-5);
	
		System.out.println(lst.toString());

		// create another list:
		LinkedListInteger lst2 = new LinkedListInteger(new int[] {7, -1, 3, 8});
		System.out.println(lst2.toString());

		LinkedListInteger newList = lst.mergeList(lst2);
		System.out.println(newList.toString());
		
	}

}
