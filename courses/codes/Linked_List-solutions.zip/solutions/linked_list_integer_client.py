class Node:
    def __init__(self, val=0, nxt=None):
        self.val = val
        self.next = nxt

    def __str__(self):
        return "[" + str(self.val) + "] "

class LinkedListInteger:
    def __init__(self, nums=[]):
        self.head = None
        self.size = 0
        for num in nums:
            n = Node(num)
            self.insert_at_tail(n)
        self.size = len(nums)

    def get_size(self):
        return self.size

    def get_head(self):
        return self.head

    def insert_at_head(self, n):
        n.next = self.head
        self.head = n
        self.size += 1

    def insert_at_tail(self, n):
        if self.size > 0:
            temp = self.head
            while temp.next:
                temp = temp.next
            temp.next = n
        else:
            self.head = n
        self.size += 1

    def remove_head(self):
        value = self.head.val
        self.head = self.head.next
        self.size -= 1
        return value

    def remove_tail(self):
        if self.size == 1:
            value = self.head.val
            self.head = None
        else:
            temp = self.head
            while temp.next.next:
                temp = temp.next
            value = temp.next.val
            temp.next = None
        self.size -= 1
        return value

    def concat_list(self, other):
        temp = self.head
        while temp.next:
            temp = temp.next
        temp.next = other.head
        return self

    def intertwine_list(self, other):
        result = LinkedListInteger()
        long_list = self if self.size >= other.size else other
        short_list = self if self.size < other.size else other
        temp_long = long_list.head
        temp_short = short_list.head
        while temp_long and temp_short:
            result.insert_at_tail(Node(temp_long.val))
            result.insert_at_tail(Node(temp_short.val))
            temp_long = temp_long.next
            temp_short = temp_short.next
        if temp_long:
            result.insert_at_tail(Node(temp_long.val))
        self.head = result.head
        self.size = result.size
        return result

    def __str__(self):
        string_representation = ""
        temp = self.head
        while temp:
            string_representation += str(temp) + "--> "
            temp = temp.next
        string_representation += "null"
        return string_representation

# Client program
if __name__ == "__main__":
    n1 = Node(9)
    n2 = Node(-4)
    n3 = Node(2)
    n4 = Node(-3)
    n5 = Node(-5)

    lst = LinkedListInteger()
    lst.insert_at_tail(n2)
    lst.insert_at_tail(n3)
    lst.insert_at_tail(n4)
    lst.insert_at_tail(n5)
    lst.insert_at_head(n1)

    print(lst)
    lst.remove_tail()
    print(lst)
    lst.remove_head()
    print(lst)

    lst2 = LinkedListInteger([7, -1, 3, 8])
    print(lst2)

    new_list = lst.concat_list(lst2)
    print(new_list)
    new_list = lst.intertwine_list(lst2)
    print(new_list)
