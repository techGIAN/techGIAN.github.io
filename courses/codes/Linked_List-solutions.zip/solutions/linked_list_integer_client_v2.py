class Node:
    def __init__(self, val=0, nxt=None):
        self.val = val
        self.next = nxt

    def __str__(self):
        return "[" + str(self.val) + "] "

class LinkedListInteger:
    def __init__(self):
        self.head = None
        self.size = 0

    def insert(self, x):
        node = Node(x)
        if self.size == 0:
            self.head = node
        else:
            node_inserted = False
            prev = None
            curr = self.head
            while curr:
                if node.val <= curr.val:
                    node.next = curr
                    if prev is None:
                        self.head = node
                    else:
                        prev.next = node
                    node_inserted = True
                    break
                prev = curr
                curr = curr.next
            if not node_inserted:
                prev.next = node
        self.size += 1

    def remove(self, x):
        prev = None
        curr = self.head
        while curr and curr.val != x:
            prev = curr
            curr = curr.next
        if prev:
            prev.next = curr.next
        else:
            self.head = curr.next
        self.size -= 1
        return x

    def merge_list(self, other):
        result = LinkedListInteger()
        temp1 = self.head
        temp2 = other.head
        while temp1 and temp2:
            if temp1.val >= temp2.val:
                result.insert(temp2.val)
                temp2 = temp2.next
            else:
                result.insert(temp1.val)
                temp1 = temp1.next
        while temp1:
            result.insert(temp1.val)
            temp1 = temp1.next
        while temp2:
            result.insert(temp2.val)
            temp2 = temp2.next
        self.head = result.head
        self.size = result.size
        return result

    def __str__(self):
        string_representation = ""
        temp = self.head
        while temp:
            string_representation += str(temp) + "--> "
            temp = temp.next
        string_representation += "null"
        return string_representation

if __name__ == "__main__":
    lst = LinkedListInteger()
    lst.insert(9)
    lst.insert(-4)
    lst.insert(2)
    lst.insert(-3)
    lst.insert(-5)
    print(lst)

    lst2 = LinkedListInteger()
    lst2.insert(7)
    lst2.insert(-1)
    lst2.insert(3)
    lst2.insert(8)
    print(lst2)

    newList = lst.merge_list(lst2)
    print(newList)
