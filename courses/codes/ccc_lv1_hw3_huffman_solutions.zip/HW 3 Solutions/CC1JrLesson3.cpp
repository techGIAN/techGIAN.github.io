// CC1JrLesson3.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include "Huffman.h"
using namespace std;

void parseTree(Huffman* tree, string inputString) {
    Huffman* t = tree;
    for (int i = 0; i < inputString.length(); ++i) {
        if (inputString[i] == '0') {
            t = t->zero;
        } else if (inputString[i] == '1') {
            t = t->one;
        } else {
            cerr << "Invalid character " << inputString[i] << endl;
        }

        if (t->value != NULL) {
            cout << t->value;
            t = tree;
        }
    }
    cout << endl;
}

Huffman* buildTree(int n) {
    Huffman* tree = new Huffman;
    for (int i = 0; i < n; ++i) {
        char c;
        string str;
        cin >> c;
        cin >> str;
        Huffman* t = tree;
        for (int j = 0; j < str.length(); ++j) {
            if (str[j] == '0') {
                if (t->zero == NULL) {
                    t->zero = new Huffman;
                }
                t = t->zero;
            } else if (str[j] == '1') {
                if (t->one == NULL) {
                    t->one = new Huffman;
                }
                t = t->one;
            }
        }
        t->value = c;
    }

    return tree;
}
int main() {
    int N;
    cin >> N;
    Huffman* myTree = buildTree(N);
    string S;
    cin >> S;
    parseTree(myTree, S);
    delete myTree;
}


