#include <iostream>
#include "Huffman.h"
using namespace std;

Huffman::Huffman(): value('\0'), zero(NULL), one(NULL) {
}

Huffman::~Huffman() {
	if (zero != NULL) {
		delete zero;
	}
	if (one != NULL) {
		delete one;
	}
}

