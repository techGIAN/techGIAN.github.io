#pragma once

class Huffman {
public:
    Huffman();
    ~Huffman();

    char value;
    Huffman* zero;
    Huffman* one;
};
