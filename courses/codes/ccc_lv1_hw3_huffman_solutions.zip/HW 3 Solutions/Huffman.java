public class Huffman {
    Character value;
    Huffman zero;
    Huffman one;

    public Huffman() {
        this.value = null;
        this.zero = null;
        this.one = null;
    }
}
