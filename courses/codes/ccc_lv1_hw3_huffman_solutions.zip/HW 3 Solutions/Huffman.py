class Huffman:

    def __init__(self):
        self.value = None
        self.zero = None
        self.one = None




