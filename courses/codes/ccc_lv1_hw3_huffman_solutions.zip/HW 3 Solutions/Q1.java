import java.util.Scanner;

public class Q1 {

    public static void parseTree(Huffman tree, String inputString) {
        Huffman t = tree;
        for (int i = 0; i < inputString.length(); ++i) {
            if (inputString.charAt(i) == '0') {
                t = t.zero;
            } else if (inputString.charAt(i) == '1') {
                t = t.one;
            } else {
                System.err.println("Invalid character " + inputString.charAt(i));
            }

            if (t.value != null) {
                System.out.print(t.value);
                t = tree;
            }
        }
        System.out.println();
    }

    public static Huffman buildTree(Scanner scan, int n) {
        Huffman tree = new Huffman();
        for (int i = 0; i < n; ++i) {
            String c = scan.next();
            String str = scan.nextLine();
            Huffman t = tree;
            for (int j = 0; j < str.length(); ++j) {
                if (str.charAt(j) == '0') {
                    if (t.zero == null) {
                        t.zero = new Huffman();
                    }
                    t = t.zero;
                } else if (str.charAt(j) == '1') {
                    if (t.one == null) {
                        t.one = new Huffman();
                    }
                    t = t.one;
                }
            }
            t.value = c.charAt(0);
        }

        return tree;
    }

    public static void main(String args[]) {
        Scanner scan = new Scanner(System.in);
        int N = Integer.parseInt(scan.nextLine());
        Huffman myTree = buildTree(scan, N);
        String S = scan.nextLine();
        parseTree(myTree, S);
        scan.close();
    }
}
