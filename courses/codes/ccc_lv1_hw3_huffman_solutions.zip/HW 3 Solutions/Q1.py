from Huffman import Huffman


def parse_tree(tree, input_string):
    t = tree
    for c in input_string:
        if c == '0':
            t = t.zero
        elif c == '1':
            t = t.one
        else:
            print("Invalid character", c)
        if t.value is not None:
            print(t.value, end='')
            t = tree
    print()


def build_tree(n):
    tree = Huffman()

    for i in range(n):
        v, s = input().split(' ')
        t = tree
        for c in s:
            if c == '0':
                if t.zero is None:
                    t.zero = Huffman()
                t = t.zero
            elif c == '1':
                if t.one is None:
                    t.one = Huffman()
                t = t.one
        t.value = v
    return tree


N = int(input())
my_tree = build_tree(N)
S = input()
parse_tree(my_tree, S)