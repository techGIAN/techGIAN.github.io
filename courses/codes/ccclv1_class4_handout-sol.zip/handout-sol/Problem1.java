import java.util.Scanner;
import java.util.Arrays;
import java.util.Collections;

public class Problem1 {
    
    public static int sumArr(Integer[] a) {
        int sum = 0;
        for (Integer x : a) {
            sum += x;
        }
        return sum;
    }
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int T = Integer.parseInt(sc.nextLine());
        for (int t = 0; t < T; t++) {
            String input = sc.nextLine();
            String[] scoreString = input.split(" ");
            Integer[] scores = new Integer[scoreString.length];
            for (int i = 0; i < scores.length; i++) {
                scores[i] = Integer.parseInt(scoreString[i]);
            }
            int[] ranks = new int[scores.length];
            
            int r = 1;
            int nextPlaceScore = Collections.max(Arrays.asList(scores));
            int nextPlaceIx = 0;
            
            while (sumArr(scores) > 0) {
                
                nextPlaceIx = Arrays.asList(scores).indexOf(nextPlaceScore);
                ranks[nextPlaceIx] = r;
                r++;
                scores[nextPlaceIx] = 0;
                nextPlaceIx = 0;
                nextPlaceScore = Collections.max(Arrays.asList(scores));
                
            }
            
            for (int rank : ranks) {
                if (rank == 1) {
                    System.out.print("Gold ");
                } else if (rank == 2) {
                    System.out.print("Silver ");
                } else if (rank == 3) {
                    System.out.print("Bronze ");
                } else {
                    System.out.print(rank + " ");
                }
            }
            System.out.println();
        }
        sc.close();
    }
}