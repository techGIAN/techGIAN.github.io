import java.util.Scanner;
import java.util.Arrays;
import java.util.Collections;

public class Problem2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int T = Integer.parseInt(sc.nextLine());
        for (int t = 0; t < T; t++) {
            String input = sc.nextLine();
            String[] rodsString = input.split(" ");
            Integer[] rods = new Integer[rodsString.length];
            for (int i = 0; i < rods.length; i++) {
                rods[i] = Integer.parseInt(rodsString[i]);
            }
            int nChooseThree = rods.length * (rods.length - 1) * (rods.length - 2) / 6;
            Integer[] rodCombos = new Integer[nChooseThree];
            
            int p = 0;
            for (int i = 0; i < rods.length; i++) {
                for (int j = i+1; j < rods.length; j++) {
                    for (int k = j+1; k < rods.length; k++) {
                        boolean b1 = rods[i] + rods[j] > rods[k];
                        boolean b2 = rods[i] + rods[k] > rods[j];
                        boolean b3 = rods[k] + rods[j] > rods[i];
                        if (b1 && b2 && b3) {
                            rodCombos[p] = rods[i] + rods[j] + rods[k];
                        } else {
                            rodCombos[p] = 0;
                        }
                        p++;
                    }
                }
            }
            
            System.out.println(Collections.max(Arrays.asList(rodCombos)));
        }
        sc.close();
    }
}