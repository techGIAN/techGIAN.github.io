import java.util.Scanner;

public class Problem3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int T = Integer.parseInt(sc.nextLine());
        for (int t = 0; t < T; t++) {
            String input = sc.nextLine();
            String[] billString = input.split(" ");
            int[] bills = new int[billString.length];
            for (int i = 0; i < bills.length; i++) {
                bills[i] = Integer.parseInt(billString[i]);
            }
            int[] reg = new int[3];
            boolean possible = true;
            for (int b : bills) {
                if (b == 5) {
                    reg[0]++;
                } else if (b == 10) {
                    reg[1]++;
                    reg[0]--;
                } else { 
                    if (reg[1] > 0) {
                        reg[1]--;
                        reg[0]--;
                    } else {
                        reg[0] -= 3;
                    }
                    reg[2]++;
                }
                if (reg[0] < 0) {
                    possible = false;
                    break;
                }
            }
            
            System.out.println(possible);
        }
        sc.close();
    }
}