#include <iostream>
#include <sstream>
#include <vector>
#include <algorithm>
#include <numeric>

using namespace std;

int sumArr(const vector<int>& a) {
    return accumulate(a.begin(), a.end(), 0);
}

int main() {
    int T;
    string input;

    // Input the number of test cases
    cout << "";
    cin >> T;
    cin.ignore();

    for (int t = 0; t < T; t++) {
        // Input the scores
        cout << "";
        getline(cin, input);
        istringstream iss(input);

        vector<int> scores;
        int score;
        while (iss >> score) {
            scores.push_back(score);
        }

        vector<int> ranks(scores.size(), 0);
        int r = 1;
        int nextPlaceIx = 0;

        // Start the ranking process
        while (sumArr(scores) > 0) {
            auto maxIt = max_element(scores.begin(), scores.end());
            nextPlaceIx = distance(scores.begin(), maxIt);
            ranks[nextPlaceIx] = r;
            r++;
            scores[nextPlaceIx] = 0;
        }

        // Output the results
        for (int rank : ranks) {
            if (rank == 1) {
                cout << "Gold ";
            } else if (rank == 2) {
                cout << "Silver ";
            } else if (rank == 3) {
                cout << "Bronze ";
            } else {
                cout << rank << " ";
            }
        }
        cout << endl;
    }

    return 0;
}