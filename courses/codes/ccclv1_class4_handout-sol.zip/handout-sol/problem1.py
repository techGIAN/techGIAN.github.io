T = int(input())

for _ in range(T):
    scores = [int(x) for x in input().split(' ')]
    ranks = [0]*len(scores)
    
    r = 1
    next_place_score = max(scores)
    next_place_ix = 0
    while sum(scores) > 0:
        
        next_place_ix = scores.index(next_place_score)
        ranks[next_place_ix] = r
        r += 1
        scores[next_place_ix] = 0
        next_place_ix = 0
        next_place_score = max(scores)
        
    g = ranks.index(1)
    ranks = ranks[:g] + ['Gold'] + ranks[g+1:]
    
    s = ranks.index(2)
    ranks = ranks[:s] + ['Silver'] + ranks[s+1:]
    
    b = ranks.index(3)
    ranks = ranks[:b] + ['Bronze'] + ranks[b+1:]

    print(' '.join([str(x) for x in ranks]))