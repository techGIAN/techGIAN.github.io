#include <iostream>
#include <vector>
#include <algorithm>
#include <sstream>

using namespace std;

int main() {
    int T;
    cout << "";
    cin >> T;
    cin.ignore(); // ignore the newline character after reading the integer
    
    for (int t = 0; t < T; t++) {
        string input;
        cout << "";
        getline(cin, input);
        
        istringstream iss(input);
        vector<int> rods;
        int rod;
        while (iss >> rod) {
            rods.push_back(rod);
        }
        
        int nChooseThree = rods.size() * (rods.size() - 1) * (rods.size() - 2) / 6;
        vector<int> rodCombos(nChooseThree, 0); // initialize all values to 0
        
        int p = 0;
        for (int i = 0; i < rods.size(); i++) {
            for (int j = i + 1; j < rods.size(); j++) {
                for (int k = j + 1; k < rods.size(); k++) {
                    bool b1 = rods[i] + rods[j] > rods[k];
                    bool b2 = rods[i] + rods[k] > rods[j];
                    bool b3 = rods[k] + rods[j] > rods[i];
                    
                    if (b1 && b2 && b3) {
                        rodCombos[p] = rods[i] + rods[j] + rods[k];
                    } else {
                        rodCombos[p] = 0;
                    }
                    p++;
                }
            }
        }

        // Find the maximum sum of valid rod combinations
        auto maxCombo = max_element(rodCombos.begin(), rodCombos.end());
        cout << *maxCombo << endl;
    }

    return 0;
}