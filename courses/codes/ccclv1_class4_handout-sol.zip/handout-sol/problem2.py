T = int(input())

for _ in range(T):
    rods = [int(x) for x in input().split(' ')]
    rod_combos = []
    
    for i in range(len(rods)):
        for j in range(i+1, len(rods)):
            for k in range(j+1, len(rods)):
                b1 = rods[i] + rods[j] > rods[k]
                b2 = rods[i] + rods[k] > rods[j]
                b3 = rods[k] + rods[j] > rods[i]
                if b1 and b2 and b3:
                    rod_combos.append((rods[i], rods[j], rods[k]))

    perimeters = [sum(x) for x in rod_combos]    
    print(max(perimeters) if len(perimeters) > 0 else 0)