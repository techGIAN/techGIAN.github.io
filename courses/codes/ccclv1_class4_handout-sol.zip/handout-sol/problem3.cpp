#include <iostream>
#include <sstream>
#include <vector>

using namespace std;

int main() {
    int T;
    cout << "";
    cin >> T;
    cin.ignore(); // To ignore the newline after entering T

    for (int t = 0; t < T; t++) {
        string input;
        cout << "";
        getline(cin, input);

        istringstream iss(input);
        vector<int> bills;
        int bill;
        while (iss >> bill) {
            bills.push_back(bill);
        }

        int reg[3] = {0, 0, 0}; // reg[0] for $5 bills, reg[1] for $10 bills, reg[2] for $20 bills
        bool possible = true;

        for (int b : bills) {
            if (b == 5) {
                reg[0]++;  // Collect a $5 bill
            } else if (b == 10) {
                reg[1]++;  // Collect a $10 bill
                reg[0]--;  // Give back a $5 bill as change
            } else { // for $20 bills
                if (reg[1] > 0) {
                    reg[1]--;  // Give back one $10 bill as change
                    reg[0]--;  // Give back one $5 bill as change
                } else {
                    reg[0] -= 3;  // Give back three $5 bills as change
                }
                reg[2]++;
            }

            if (reg[0] < 0) {
                possible = false;
                break;
            }
        }

        cout << (possible ? "true" : "false") << endl;
    }

    return 0;
}