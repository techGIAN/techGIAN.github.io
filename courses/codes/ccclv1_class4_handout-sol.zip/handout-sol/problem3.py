T = int(input())

for _ in range(T):
    possible = True
    bills = [int(x) for x in input().split(' ')]
    
    # reg[0] to hold number of $5 bills
    # reg[1] for $10 bills
    # reg[2] for $20 bills
    reg = [0, 0, 0]

    for b in bills:

        # customer has exact money, no change given
        if b == 5:
            reg[0] += 1

        # give $5 bill as change
        elif b == 10:
            reg[1] += 1
            reg[0] -= 1

        # customer gives $20 bill
        # greedily save the $5s by giving a change of $10 + $5 first
        # if there are no more $10s, then give the $5s
        else:
            if reg[1] > 0:
                reg[1] -= 1
                reg[0] -= 1
            else:
                reg[0] -= 3
            reg[2] += 1

        if reg[0] < 0:
            possible = False
            break

    print(possible)


