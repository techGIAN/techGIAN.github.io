import java.util.Arrays;

public class ArrayQueue {

	private Object[] myQueue;
	private Object front;
	private int frontIndex, rearIndex;
	private int size;
	private int MAX_SIZE;
	
	public ArrayQueue() {
		this(1000);
	}
	
	public ArrayQueue(int maxSize) {
		this.MAX_SIZE = maxSize;
		this.myQueue = new Object[maxSize];
		this.front = null;
		this.frontIndex = -1;
		this.rearIndex = 0;
		this.size = 0;
	}
	
	public void enqueue(Object x) {
		if (this.rearIndex == MAX_SIZE) {
			return;
		}
		this.myQueue[this.rearIndex] = x;
		this.size += 1;
		this.rearIndex += 1;
		
		if (this.size == 1) {
			this.front = x;
			this.frontIndex += 1;
		}
	}
	
	public boolean isEmpty() {
		return (this.size == 0);
	}
	
	public Object dequeue() {
		if (this.isEmpty()) {
			return null;
		}
		Object x = this.front;
		this.myQueue[this.frontIndex] = null;
		this.frontIndex += 1;
		this.size -= 1;
		this.front = this.isEmpty() ? null : this.myQueue[this.frontIndex];
		return x;
	}

	public Object front() {
		return this.front;
	}
	
	public int size() {
		return this.size;
	}
	
	// method not necessary
	public void prettyPrint() {
		Object[] arr = Arrays.copyOfRange(this.myQueue, 0, this.rearIndex);
		System.out.println(Arrays.toString(arr));
	}
	
}
