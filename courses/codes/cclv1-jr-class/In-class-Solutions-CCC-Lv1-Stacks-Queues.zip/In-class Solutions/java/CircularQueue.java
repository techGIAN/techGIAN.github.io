import java.util.Arrays;

public class CircularQueue {

	private Object[] myQueue;
	private int frontIndex, rearIndex;
	private int size;
	private int MAX_SIZE;
	
	public CircularQueue() {
		this(1000);
	}
	
	public CircularQueue(int maxSize) {
		this.MAX_SIZE = maxSize;
		this.myQueue = new Object[maxSize];

		this.frontIndex = 0;
		this.rearIndex = 0;
		this.size = 0;
	}
	
	public void enqueue(Object x) {
		if (this.isFull()) {
			return;
		} 
		this.myQueue[this.rearIndex] = x;
		this.rearIndex = ((this.rearIndex + 1) % this.MAX_SIZE);
		this.size += 1;
		
	}
	
	public boolean isEmpty() {
		return (this.frontIndex == this.rearIndex);
	}
	
	public boolean isFull() {
		return ((this.rearIndex + 1) % this.MAX_SIZE == this.frontIndex);
	}
	
	
	public Object dequeue() {
		if (this.isEmpty()) {
			return null;
		}
		Object x = this.myQueue[this.frontIndex];
		this.myQueue[this.frontIndex] = null;
		this.frontIndex = ((this.frontIndex + 1) % this.MAX_SIZE);
		this.size -= 1;
		return x;
	}

	public Object peek() {
		return this.myQueue[this.frontIndex];
	}
	
	public int size() {
		return this.size;
	}
	
	// method not necessary
	public void prettyPrint() {
		Object[] arr;
		if (this.frontIndex <=  this.rearIndex) {
			arr = Arrays.copyOfRange(this.myQueue, this.frontIndex, this.rearIndex);
		} else {
			arr = new Object[this.size()];
			System.arraycopy(this.myQueue, this.frontIndex, arr, 0, this.MAX_SIZE - this.frontIndex);
			System.arraycopy(this.myQueue, 0, arr, this.MAX_SIZE - this.frontIndex, this.rearIndex);
		}
		System.out.println(Arrays.toString(arr));
	}
	
	public void prettyPrintAll() {
		System.out.println(Arrays.toString(this.myQueue));
	}
	

	
	public int getMaxSize() {
		return this.MAX_SIZE;
	}
}
