import java.util.List;
import java.util.ArrayList;

public class ListStack {
	
	private List<Object> myStack;
	private int size;
	private Object top;
	
	public ListStack() {
		this.myStack = new ArrayList<>();
		this.size = 0;
		this.top = null;
	}
	
	public void push(Object x) {
		myStack.add(x);
		this.top = x;
		this.size++;
	}
	
	public boolean isEmpty() {
		return this.size == 0;
	}
	
	public Object top() {
		return this.top;
	}
	
	public int size() {
		return this.size;
	}
	
	public Object pop() {
		if (this.isEmpty()) {
			return null;
		}
		Object x = this.top;
		this.myStack.remove(this.size - 1);
		this.size--;
		this.top = (this.isEmpty()) ? null : this.myStack.get(this.size - 1);
		return x;
	}
}
