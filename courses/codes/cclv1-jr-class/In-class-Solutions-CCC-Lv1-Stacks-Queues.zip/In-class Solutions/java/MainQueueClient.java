
public class MainQueueClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		arrayQueue();
		circularQueue();
	}
	
	public static void arrayQueue() {
		ArrayQueue aq = new ArrayQueue(5);
		System.out.println(aq.isEmpty());
		aq.enqueue(5);
		System.out.println(aq.isEmpty());
		System.out.println(aq.front());
		aq.prettyPrint();
		aq.enqueue(7);
		aq.enqueue(12);
		aq.prettyPrint();
		System.out.println(aq.front());
		System.out.println(aq.dequeue());
		System.out.println(aq.size());
		System.out.println(aq.front());
		aq.prettyPrint();
		aq.enqueue(8);
		aq.enqueue(3);
		aq.prettyPrint();
		System.out.println(aq.front());
		System.out.println(aq.dequeue());
		System.out.println(aq.size());
		System.out.println(aq.front());
		aq.prettyPrint();
		aq.enqueue(9);
		aq.prettyPrint();
	}
	
	public static void circularQueue() {
		CircularQueue cq = new CircularQueue(5);
		System.out.println(cq.isEmpty());
		cq.enqueue(5);
		System.out.println(cq.isEmpty());
		System.out.println(cq.peek());
		cq.prettyPrint();
		cq.enqueue(7);
		cq.enqueue(12);
		cq.prettyPrint();
		System.out.println(cq.peek());
		System.out.println(cq.dequeue());
		System.out.println(cq.size());
		System.out.println(cq.peek());
		cq.prettyPrint();
		cq.enqueue(8);
		cq.enqueue(3);
		cq.prettyPrint();
		System.out.println(cq.peek());
		System.out.println(cq.dequeue());
		System.out.println(cq.size());
		System.out.println(cq.peek());
		cq.prettyPrint();
		cq.enqueue(9);
		cq.prettyPrint();
	}
	

}
