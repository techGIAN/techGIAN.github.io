
public class StackExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ListStack s = new ListStack();
		System.out.println(s.isEmpty());
		s.push(3);
		s.push(8);
		System.out.println(s.top());
		s.push(5);
		System.out.println(s.isEmpty());
		s.push(6);
		System.out.println(s.top());
		System.out.println(s.pop());
		System.out.println(s.top());
	}

}
