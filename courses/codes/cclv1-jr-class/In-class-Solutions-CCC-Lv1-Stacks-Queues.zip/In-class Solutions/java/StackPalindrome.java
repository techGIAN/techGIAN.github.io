
public class StackPalindrome {

	public static boolean twoStack(String s) {
		ListStack forwardStack = new ListStack();
		ListStack backwardStack = new ListStack();
		
		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			forwardStack.push(c);
		}
		
		for (int i = s.length() - 1; i >= 0; i--) {
			char c = s.charAt(i);
			backwardStack.push(c);
		}
		
		while (!forwardStack.isEmpty()) {
			Character c1 = (Character) forwardStack.pop();
			Character c2 = (Character) backwardStack.pop();
			
			if (c1 != c2) {
				return false;
			}
		}
		
		return true;
	}
	
	public static boolean oneStack(String s) {
		ListStack S = new ListStack();
		
		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			S.push(c);
		}
		
		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			if ((Character) S.pop() != c) {
				return false;
			}
		}
		
		return true;
	}
	
	public static void main(String[] args) {
		String s1 = "racecar";
		String s2 = "abracadabra";
		
		System.out.println(twoStack(s1));
		System.out.println(oneStack(s1));
		System.out.println(twoStack(s2));
		System.out.println(oneStack(s2));
	}

}
