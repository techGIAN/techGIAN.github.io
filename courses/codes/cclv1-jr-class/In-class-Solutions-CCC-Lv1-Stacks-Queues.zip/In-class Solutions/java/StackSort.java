
public class StackSort {

	public static void main(String[] args) {
		// create some stack S
		ListStack S = new ListStack();
		S.push(15);
		S.push(9);
		S.push(49);
		S.push(68);
		S.push(3);
		S.push(41);
		S.push(31);
		S.push(22);
		S.push(54);
		S.push(11);
		
		// sort elements in S so that the largest is at the bottom
		
		// begin by creating an aux stack A, then push all items in S to A
		ListStack A = new ListStack();
		while (!S.isEmpty()) {
			A.push(S.pop());
		}
		
		while (!A.isEmpty()) {
			Integer temp = (Integer) A.pop();		// store first into some temp var
			// find the right spot in S where to place item temp
			while (!S.isEmpty() && (Integer) S.top() < temp) {
				A.push(S.pop());
			}
			S.push(temp);
		}
		
		// verify that the stack S is sorted
		while (!S.isEmpty()) {
			System.out.println(S.pop());
		}
	}

}
