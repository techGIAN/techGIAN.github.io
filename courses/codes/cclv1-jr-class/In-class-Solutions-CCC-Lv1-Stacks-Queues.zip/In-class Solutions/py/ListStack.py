class ListStack:

    def __init__(self):
        self.my_stack = []
        self.size_of_stack = 0
        self.top_item = None

    def push(self, x):
        self.my_stack.append(x)
        self.size_of_stack += 1
        self.top_item = x

    def is_empty(self):
        return (self.size_of_stack == 0)

    def top(self):
        return self.top_item

    def size(self):
        return self.size_of_stack

    def pop(self):
        if self.is_empty():
            return None
        else:
            x = self.top()
            self.my_stack = self.my_stack[:-1]
            self.size_of_stack -= 1
            self.top_item = None if self.is_empty() else self.my_stack[-1]
            return x

