class ArrayQueue:

    def __init__(self, max_size=1000):
        self.MAX_SIZE = max_size
        self.myQueue = [None] * self.MAX_SIZE
        self.front = None
        self.front_ix = -1
        self.rear_ix = 0
        self.size = 0

    def enqueue(self, x):
        if self.rear_ix == self.MAX_SIZE:
            return
        self.myQueue[self.rear_ix] = x
        self.rear_ix += 1
        self.size += 1

        if (self.size == 1):
            self.front = x
            self.front_ix += 1

    def isEmpty(self):
        return self.get_size() == 0

    def dequeue(self):
        if self.isEmpty():
            return None
        x = self.front
        self.myQueue[self.front_ix] = None
        self.front_ix += 1
        self.size -= 1
        self.front = None if self.isEmpty() else self.myQueue[self.front_ix]
        return x

    def peek(self):
        return self.front

    def get_size(self):
        return self.size

    # not really needed
    def pretty_print(self):
        print(self.myQueue[:self.rear_ix])

if __name__ == "__main__":
    Q = ArrayQueue(5)
    print(Q.isEmpty())
    Q.enqueue(5)
    print(Q.isEmpty())
    print(Q.peek())
    Q.pretty_print()
    Q.enqueue(7)
    Q.enqueue(12)
    Q.pretty_print()
    print(Q.peek())
    print(Q.dequeue())
    print(Q.get_size())
    print(Q.peek())
    Q.pretty_print()
    Q.enqueue(8)
    Q.enqueue(3)
    Q.pretty_print()
    print(Q.peek())
    print(Q.dequeue())
    print(Q.get_size())
    print(Q.peek())
    Q.pretty_print()
    Q.enqueue(9)
    Q.pretty_print()