class CircularQueue:

    def __init__(self, max_size=1000):
        self.MAX_SIZE = max_size
        self.myQueue = [None] * self.MAX_SIZE
        self.front_ix, self.rear_ix = 0, 0
        self.size = 0

    def enqueue(self, x):
        if self.isFull():
            return
        self.myQueue[self.rear_ix] = x
        self.rear_ix = (self.rear_ix + 1) % self.MAX_SIZE
        self.size += 1

    def isEmpty(self):
        return self.front_ix == self.rear_ix

    def isFull(self):
        return (self.rear_ix + 1) % self.MAX_SIZE == self.front_ix

    def dequeue(self):
        if self.isEmpty():
            return None
        x = self.myQueue[self.front_ix]
        self.myQueue[self.front_ix] = None
        self.front_ix = (self.front_ix + 1) % self.MAX_SIZE
        self.size -= 1
        return x

    def peek(self):
        return self.myQueue[self.front_ix]

    def get_size(self):
        return self.size

    # not really needed
    def pretty_print(self):
        print(self.myQueue)

if __name__ == "__main__":
    Q = CircularQueue(5)
    print(Q.isEmpty())
    Q.enqueue(5)
    print(Q.isEmpty())
    print(Q.peek())
    Q.pretty_print()
    Q.enqueue(7)
    Q.enqueue(12)
    Q.pretty_print()
    print(Q.peek())
    print(Q.dequeue())
    print(Q.get_size())
    print(Q.peek())
    Q.pretty_print()
    Q.enqueue(8)
    Q.enqueue(3)
    Q.pretty_print()
    print(Q.peek())
    print(Q.dequeue())
    print(Q.get_size())
    print(Q.peek())
    Q.pretty_print()
    Q.enqueue(9)
    Q.pretty_print()