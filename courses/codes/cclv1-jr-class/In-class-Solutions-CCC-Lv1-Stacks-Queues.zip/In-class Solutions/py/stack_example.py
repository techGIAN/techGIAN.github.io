from ListStack import ListStack

S = ListStack()
print(S.is_empty())
S.push(3)
S.push(8)
print(S.top())
S.push(5)
print(S.is_empty())
S.push(6)
print(S.top())
print(S.pop())      # calling S.pop() only will pop the top element but not display it
print(S.top())