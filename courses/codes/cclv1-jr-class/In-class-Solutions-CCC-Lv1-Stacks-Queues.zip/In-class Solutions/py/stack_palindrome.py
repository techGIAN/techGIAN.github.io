from ListStack import ListStack

def two_stack(s):
    forward_stack = ListStack()
    backward_stack = ListStack()

    for c in s:
        forward_stack.push(c)

    # reverses the string
    for c in s[::-1]:
        backward_stack.push(c)

    while not forward_stack.is_empty():
        c1 = forward_stack.pop()
        c2 = backward_stack.pop()

        if c1 != c2:
            # string does not read forward and back
            # not a palindrome
            return False

    return True

def one_stack(s):
    S = ListStack()

    for c in s:
        S.push(c)

    for c in s:
        if S.pop() != c:
            return False

    return True


s1 = "racecar"
s2 = "abracadabra"
print(two_stack(s1))
print(one_stack(s1))
print(two_stack(s2))
print(one_stack(s2))