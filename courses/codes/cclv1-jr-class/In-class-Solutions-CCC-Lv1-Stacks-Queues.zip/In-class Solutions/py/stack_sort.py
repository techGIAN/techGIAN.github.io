from ListStack import ListStack

# create some stack S
S = ListStack()
S.push(15)
S.push(9)
S.push(49)
S.push(68)
S.push(3)
S.push(41)
S.push(31)
S.push(22)
S.push(54)
S.push(11)

# sort the elements in S so that the largest one is at the bottom of the stack

# begin by creating an aux stack and empty the elements of S and transfer (push) them onto A
A = ListStack()
while not S.is_empty():
    A.push(S.pop())

while not A.is_empty():
    temp = A.pop()      # store first into some temp var
    while not S.is_empty() and S.top() < temp:   # find the "right spot in S" where you should place the element temp
        A.push(S.pop())
    S.push(temp)

# verify that the stack S is sorted
while not S.is_empty():
    print(S.pop())

