class Reindeer:

    def __init__(self, name="", next=None):
        self.name = name
        self.next = next