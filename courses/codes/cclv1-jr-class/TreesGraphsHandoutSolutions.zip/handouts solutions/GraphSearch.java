import java.util.*;
import java.lang.Math;

public class GraphSearch {
	
	// create a class called Pair to handle ordered pairs
	public static class Pair<X, Y> {
        public final X x;
        public final Y y;
        
        public Pair(X x, Y y) {
            this.x = x;
            this.y = y;
        }
        
        public void print() {
            System.out.print( "(" + this.x + ", " + this.y + ")" );
        }
        
        public void print(String s) {
            System.out.println( "(" + this.x + ", " + this.y + ")" );
        }
        
        @Override
        public boolean equals(Object other) {
            if (this == other) return true;
            if (other == null || getClass() != other.getClass()) return false;
            Pair<?, ?> pair = (Pair<?, ?>) other;
            return x.equals(pair.x) && y.equals(pair.y);
        }

        @Override
        public int hashCode() {
            int result = x != null ? x.hashCode() : 0;
            result = 31 * result + (y != null ? y.hashCode() : 0);
            return result;
        }
    }
	 
	// implemented as a Queue
	public static void bfs(Map<Object, List<Object>> G) {
		Queue<Object> Q = new LinkedList<>();
		Map<Object, Boolean> V = new HashMap<>();
		for (Object node : G.keySet()) {
			V.put(node, false);
		}
		
		List<Object> my_nodes = new ArrayList<Object>();
		my_nodes.addAll(G.keySet());
		Q.add(my_nodes.get(0));
		V.put(my_nodes, true);
		
		while (!Q.isEmpty()) {
			Object node = Q.poll();
			System.out.print(node + " ");
			
			for (Object nbr : G.get(node)) {
				if (!V.get(nbr)) {
					V.put(nbr, true);
					Q.add(nbr);
				}
			}
			
		}
		
	}
	
	// implemented as a Stack
	public static void dfs(Map<Object, List<Object>> G) {
		Stack<Object> S = new Stack<>();
		Map<Object, Boolean> V = new HashMap<>();
		for (Object node : G.keySet()) {
			V.put(node, false);
		}
		
		List<Object> my_nodes = new ArrayList<Object>();
		my_nodes.addAll(G.keySet());
		S.push(my_nodes.get(0));
		
		while (!S.isEmpty()) {
			Object node = S.pop();
			if (!V.get(node)) {
				V.put(node, true);
				System.out.print(node + " ");
				
				for (Object nbr : G.get(node)) {
					if (!V.get(nbr)) {
						S.push(nbr);
					}
				}
			}
			
		}
		
	}
	
	// implemented as a Stack
	public static boolean dfs_q2(Map<Pair<Integer, Integer>, List<Pair<Integer, Integer>>> G, List<Pair<Integer, Integer>> foodLocs, Integer C, Pair<Integer, Integer> destLoc) {
		Stack<Pair<Integer, Integer>> S = new Stack<>();
		Map<Pair<Integer, Integer>, Boolean> V = new HashMap<>();
		for (Pair<Integer, Integer> node : G.keySet()) {
			V.put(node, false);
		}
		
//		for (Map.Entry<Pair<Integer, Integer>, Boolean> e : V.entrySet()) {
//			e.getKey().print();
//			System.out.println(" - " + e.getValue());
//		}
		
		int numOfFoodObtained = 0;
		boolean destReached = false;
		S.push(new Pair<>(0,0));
		
		while (!S.isEmpty()) {
			Pair<Integer, Integer> node = S.pop();
			if (!V.get(node)) {
				V.put(node, true);
				
				if (foodLocs.contains(node)) {
					numOfFoodObtained++;
				}
				if (node.equals(destLoc)) {
					destReached = true;
				}
				
				for (Pair<Integer, Integer> nbr : G.get(node)) {
					if (!V.get(nbr)) {
						S.push(nbr);
					}
				}
			}
			
		}
		
		return numOfFoodObtained >= C && destReached;
		
	}
	
	public static boolean bfs_q3(Map<Integer, List<Integer>> G, Integer q) {
		Queue<Integer> Q = new LinkedList<>();
		Map<Integer, Boolean> V = new HashMap<>();
		for (Integer node : G.keySet()) {
			V.put(node, false);
		}
		
		List<Integer> my_nodes = new ArrayList<Integer>();
		my_nodes.addAll(G.keySet());
		Q.add(my_nodes.get(0));
		V.put(my_nodes.get(0), true);
		
		while (!Q.isEmpty()) {
			Integer node = Q.poll();
			
			for (Integer nbr : G.get(node)) {
				if (!V.get(nbr)) {
					V.put(nbr, true);
					Q.add(nbr);
				}
			}
			
		}
		
		return (!V.containsKey(q)) ? false : V.get(q);
		
	}
	
	public static List<Pair<Pair<Integer, Integer>, Pair<Integer, Integer>>> getPairList(List<Pair<Integer, Integer>> nodes) {
		List<Pair<Pair<Integer, Integer>, Pair<Integer, Integer>>> pairs = new ArrayList<>();
		for (int i = 0; i < nodes.size(); i++) {
			for (int j = i; j < nodes.size(); j++) {
				Pair<Pair<Integer, Integer>, Pair<Integer, Integer>> pair = new Pair<>(nodes.get(i), nodes.get(j));
				pairs.add(pair);
			}
		}
		return pairs;
	}
	
	public static void q1() {
		
		// Create adj list
		Map<Object, List<Object>> G1 = new HashMap<>();
		G1.put('p', new ArrayList<>(Arrays.asList('u', 'q', 'x')));
		G1.put('q', new ArrayList<>(Arrays.asList('p', 'w', 'z')));
		G1.put('r', new ArrayList<>(Arrays.asList('v', 'u')));
		G1.put('s', new ArrayList<>(Arrays.asList('x')));
		G1.put('t', new ArrayList<>(Arrays.asList('u')));
		G1.put('u', new ArrayList<>(Arrays.asList('r', 'p', 'w', 't', 'y')));
		G1.put('v', new ArrayList<>(Arrays.asList('y', 'r')));
		G1.put('w', new ArrayList<>(Arrays.asList('u', 'q')));
		G1.put('x', new ArrayList<>(Arrays.asList('p', 's')));
		G1.put('y', new ArrayList<>(Arrays.asList('v', 'u')));
		G1.put('z', new ArrayList<>(Arrays.asList('q')));
		
		// Comment/Uncomment which you want
		bfs(G1);
		dfs(G1);
	}
	
	public static void q2() {
		Scanner sc = new Scanner(System.in);
		int C = Integer.parseInt(sc.nextLine());	// amount of food required
		int m = Integer.parseInt(sc.nextLine());	// rows
		int n = Integer.parseInt(sc.nextLine());	// cols
		
		// locations with food
		List<Pair<Integer, Integer>> foodLoc = new ArrayList<>();
		
		// Create adj list
		Map<Pair<Integer, Integer>, List<Pair<Integer, Integer>>> G2 = new HashMap<>();
		
		for (int i = 0; i < m; i++) {
			String line = sc.nextLine();
			for (int j = 0; j < n; j++) {
				if (line.charAt(j) != 'X') {
					Pair<Integer, Integer> loc = new Pair<>(i, j);
					if (!G2.containsKey(loc)) {
						G2.put(loc, new ArrayList<>());
					}
					if (line.charAt(j) == 'F') {
						foodLoc.add(loc);
					}
				}
			}
		}
		
		List<Pair<Integer, Integer>> my_nodes = new ArrayList<>();
		my_nodes.addAll(G2.keySet());
		
		for (Pair<Pair<Integer, Integer>, Pair<Integer, Integer>> combo : getPairList(my_nodes)) {
			Pair<Integer, Integer> u = combo.x;
			Pair<Integer, Integer> v = combo.y;
			if (!u.equals(v)) {
				if ((v.x == u.x && Math.abs(v.y - u.y) == 1) || (v.y == u.y && Math.abs(v.x - u.x) == 1)) {
					List<Pair<Integer, Integer>> nbrs = G2.get(u);
					nbrs.add(v);
					G2.put(u, nbrs);
					
					nbrs = G2.get(v);
					nbrs.add(u);
					G2.put(v, nbrs);
				}
			}
		}
		
		Pair<Integer, Integer> dest = new Pair<>(m-1, n-1);
		char output = dfs_q2(G2, foodLoc, C, dest) ? 'Y' : 'N';
		System.out.println(output);
		
		sc.close();
	}

	public static void q3() {
		Scanner sc = new Scanner(System.in);
		int N = Integer.parseInt(sc.nextLine());
		List<Pair<Integer, Integer>> interactions = new ArrayList<>();
		String line;
		do {
			line = sc.nextLine();
			if (!line.contains(" ")) {
				break;
			}
			String[] arr = line.split(" ");
			Pair<Integer, Integer> interaction = new Pair<>(Integer.parseInt(arr[0]), Integer.parseInt(arr[1]));
			interactions.add(interaction);
		} while(true);
		
		Integer seed = Integer.parseInt(line);
		Integer query = Integer.parseInt(sc.nextLine());
		
		int i = 0;
		for (Pair<Integer, Integer> p : interactions) {
			if (seed == p.x || seed == p.y) {
				break;
			}
			i++;
		}
		interactions = interactions.subList(i, interactions.size());
		
		Map<Integer, List<Integer>> G3 = new HashMap<>();
		for (Pair<Integer, Integer> p : interactions) {
			Integer a = p.x; Integer b = p.y;
			if (!G3.containsKey(a)) {
				G3.put(a, new ArrayList<>());
			}
			List<Integer> nbrs = G3.get(a);
			nbrs.add(b);
			G3.put(a, nbrs);
			
			if (!G3.containsKey(b)) {
				G3.put(b, new ArrayList<>());
			}
			nbrs = G3.get(b);
			nbrs.add(a);
			G3.put(b, nbrs);
		}
		
		char output = (bfs_q3(G3, query)) ? 'Y' : 'N';
		System.out.println(output);
		sc.close();
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		q1();
//		q2();
		q3();
		
//		Map<Pair<Integer, Integer>, Integer> V = new HashMap<>();
//		Pair<Integer, Integer> pair = new Pair<>(0,0);
//		V.put(pair, 10);
//		System.out.println(V.get(pair));
		
	}

}


