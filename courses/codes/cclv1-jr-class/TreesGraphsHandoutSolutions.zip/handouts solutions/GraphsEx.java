import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.List;

public class GraphsEx {

    public static HashMap<String, ArrayList<String>> createGraph() {
        HashMap<String, ArrayList<String>> adjList = new HashMap<>();
        adjList.put("A", new ArrayList<>(Set.of("B", "C")));
        adjList.put("B", new ArrayList<>(Set.of("A", "D")));
        adjList.put("C", new ArrayList<>(Set.of("A", "D")));
        adjList.put("D", new ArrayList<>(Set.of("B", "C", "E", "F")));
        adjList.put("E", new ArrayList<>(Set.of("D", "F")));
        adjList.put("F", new ArrayList<>(Set.of("D", "E")));
        return adjList;
    }

    public static ArrayList<ArrayList<String>> pathsOfLengthTwo(HashMap<String, ArrayList<String>> G) {
        ArrayList<ArrayList<String>> paths = new ArrayList<>();
        HashSet<String> visited = new HashSet<>();

        for (String node : G.keySet()) {
            for (String nbr : G.get(node)) {
                for (String nbrNbr : G.get(nbr)) {
                    if (node.equals(nbrNbr) || visited.contains(nbrNbr)) {
                        continue;
                    }
                    ArrayList<String> path = new ArrayList<>(List.of(node, nbr, nbrNbr));
                    ArrayList<String> reversedPath = new ArrayList<>(List.of(nbrNbr, nbr, node));
                    if (!paths.contains(path) && !paths.contains(reversedPath)) {
                        paths.add(path);
                    }
                }
            }
            visited.add(node);
        }
        return paths;
    }
    
    

    public static void main(String[] args) {
        HashMap<String, ArrayList<String>> G = createGraph();
        ArrayList<ArrayList<String>> paths = pathsOfLengthTwo(G);
        System.out.println(paths);
    }
}
