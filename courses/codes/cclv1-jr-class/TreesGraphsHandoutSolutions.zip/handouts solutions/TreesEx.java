//another way of creating tree is array-based approach
//each level l has 2**l nodes
//the children of the node in tree_nodes[i] is found in:
//  * tree_nodes[2*i] (left child)
//  * tree_nodes[2*i+1] (right child)
//tree_nodes = [
//    'R',
//    'A', 'B',
//    'W', 'D', null, 'M',
//    'Z', null, 'C', null, null, null, 'X', 'Y',
//    null, null, null, null, 'L', 'E', null, null, null, null, null, null, null, 'N', null, null
//]
		
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

class TreeNode {
    String value;
    TreeNode left;
    TreeNode right;

    public TreeNode(String value) {
        this.value = value;
        this.left = null;
        this.right = null;
    }
}

public class TreesEx {
    public static TreeNode createTree() {
        // Create nodes
        TreeNode root = new TreeNode("R");
        TreeNode a = new TreeNode("A");
        TreeNode b = new TreeNode("B");
        TreeNode w = new TreeNode("W");
        TreeNode d = new TreeNode("D");
        TreeNode m = new TreeNode("M");
        TreeNode z = new TreeNode("Z");
        TreeNode c = new TreeNode("C");
        TreeNode x = new TreeNode("X");
        TreeNode y = new TreeNode("Y");
        TreeNode l = new TreeNode("L");
        TreeNode e = new TreeNode("E");
        TreeNode n = new TreeNode("N");

        // Connect them
        root.left = a;
        root.right = b;

        a.left = w;
        a.right = d;

        b.right = m;

        w.left = z;

        d.left = c;

        m.left = x;
        m.right = y;

        c.left = l;
        c.right = e;

        x.right = n;

        return root;
    }

    public static List<List<String>> findAllPaths(TreeNode root) {
        List<List<String>> paths = new ArrayList<>();
        if (root == null) {
            return paths;
        }

        Queue<Pair<TreeNode, List<String>>> queue = new LinkedList<>();
        queue.offer(new Pair<>(root, new ArrayList<>(List.of(root.value))));

        while (!queue.isEmpty()) {
            Pair<TreeNode, List<String>> pair = queue.poll();
            TreeNode node = pair.getKey();
            List<String> path = pair.getValue();

            if (node.left == null && node.right == null) {
                paths.add(path);
            }

            if (node.left != null) {
                List<String> newPath = new ArrayList<>(path);
                newPath.add(node.left.value);
                queue.offer(new Pair<>(node.left, newPath));
            }

            if (node.right != null) {
                List<String> newPath = new ArrayList<>(path);
                newPath.add(node.right.value);
                queue.offer(new Pair<>(node.right, newPath));
            }
        }

        return paths;
    }

    public static List<String> searchPath(List<List<String>> paths, String tgt) {
        List<String> tgtPath = new ArrayList<>();
        for (List<String> path : paths) {
            if (!path.contains(tgt)) {
                continue;
            }

            for (int i = 0; i < path.size(); i++) {
                if (path.get(i).equals(tgt)) {
                    tgtPath = path.subList(0, i);
                    break;
                }
            }
        }

        return tgtPath;
    }

    public static String lca(TreeNode root, String n1Value, String n2Value) {
        List<List<String>> allPaths = findAllPaths(root);
        List<String> n1Path = searchPath(allPaths, n1Value);
        List<String> n2Path = searchPath(allPaths, n2Value);

        int i = 0;
        while (i < n1Path.size() && i < n2Path.size()) {
            if (!n1Path.get(i).equals(n2Path.get(i))) {
                break;
            }
            i++;
        }

        return n1Path.get(i - 1);
    }

    public static void main(String[] args) {
        TreeNode tree = createTree();
        String LCA = lca(tree, "N", "Y");
        System.out.println(LCA);
    }

    static class Pair<K, V> {
        private K key;
        private V value;

        public Pair(K key, V value) {
            this.key = key;
            this.value = value;
        }

        public K getKey() {
            return key;
        }

        public V getValue() {
            return value;
        }
    }
}
