#include <iostream>
#include <vector>
#include <unordered_map>
#include <unordered_set>
#include <stack>
#include <queue>
#include <utility>
#include <cmath>
using namespace std;

// Class for ordered pairs
template <typename X, typename Y>
class Pair {
public:
    X x;
    Y y;
    
    Pair(X x, Y y) : x(x), y(y) {}
    
    void print() {
        cout << "(" << x << ", " << y << ")";
    }
    
    void print(string s) {
        cout << "(" << x << ", " << y << ")" << endl;
    }
    
    bool operator==(const Pair<X, Y>& other) const {
        return x == other.x && y == other.y;
    }

    bool operator!=(const Pair<X, Y>& other) const {
        return !(*this == other);
    }
    
    size_t hash() const {
        return hash<X>()(x) ^ hash<Y>()(y);
    }
};

// Function to perform Breadth First Search (BFS)
template <typename T>
void bfs(unordered_map<T, vector<T>>& G) {
    queue<T> Q;
    unordered_map<T, bool> V;
    for (const auto& node : G) {
        V[node.first] = false;
    }
    
    vector<T> my_nodes;
    for (const auto& node : G) {
        my_nodes.push_back(node.first);
    }
    Q.push(my_nodes[0]);
    V[my_nodes[0]] = true;
    
    while (!Q.empty()) {
        T node = Q.front();
        Q.pop();
        cout << node << " ";
        
        for (const auto& nbr : G[node]) {
            if (!V[nbr]) {
                V[nbr] = true;
                Q.push(nbr);
            }
        }
    }
}

// Function to perform Depth First Search (DFS)
template <typename T>
void dfs(unordered_map<T, vector<T>>& G) {
    stack<T> S;
    unordered_map<T, bool> V;
    for (const auto& node : G) {
        V[node.first] = false;
    }
    
    vector<T> my_nodes;
    for (const auto& node : G) {
        my_nodes.push_back(node.first);
    }
    S.push(my_nodes[0]);
    
    while (!S.empty()) {
        T node = S.top();
        S.pop();
        if (!V[node]) {
            V[node] = true;
            cout << node << " ";
            
            for (const auto& nbr : G[node]) {
                if (!V[nbr]) {
                    S.push(nbr);
                }
            }
        }
    }
}

// Function to check if the destination can be reached while obtaining sufficient food
bool dfs_q2(unordered_map<Pair<int, int>, vector<Pair<int, int>>>& G, vector<Pair<int, int>>& foodLocs, int C, Pair<int, int> destLoc) {
    stack<Pair<int, int>> S;
    unordered_map<Pair<int, int>, bool> V;
    for (const auto& node : G) {
        V[node.first] = false;
    }
    
    int numOfFoodObtained = 0;
    bool destReached = false;
    S.push({0, 0});
    
    while (!S.empty()) {
        Pair<int, int> node = S.top();
        S.pop();
        if (!V[node]) {
            V[node] = true;
            
            if (find(foodLocs.begin(), foodLocs.end(), node) != foodLocs.end()) {
                numOfFoodObtained++;
            }
            if (node == destLoc) {
                destReached = true;
            }
            
            for (const auto& nbr : G[node]) {
                if (!V[nbr]) {
                    S.push(nbr);
                }
            }
        }
    }
    
    return numOfFoodObtained >= C && destReached;
}

// Function to perform Breadth First Search (BFS) for q3
bool bfs_q3(unordered_map<int, vector<int>>& G, int q) {
    queue<int> Q;
    unordered_map<int, bool> V;
    for (const auto& node : G) {
        V[node.first] = false;
    }
    
    vector<int> my_nodes;
    for (const auto& node : G) {
        my_nodes.push_back(node.first);
    }
    Q.push(my_nodes[0]);
    V[my_nodes[0]] = true;
    
    while (!Q.empty()) {
        int node = Q.front();
        Q.pop();
        
        for (const auto& nbr : G[node]) {
            if (!V[nbr]) {
                V[nbr] = true;
                Q.push(nbr);
            }
        }
    }
    
    return V.find(q) != V.end() && V[q];
}

// Function to generate all possible pairs from a list of nodes
vector<Pair<Pair<int, int>, Pair<int, int>>> getPairList(const vector<Pair<int, int>>& nodes) {
    vector<Pair<Pair<int, int>, Pair<int, int>>> pairs;
    for (size_t i = 0; i < nodes.size(); ++i) {
        for (size_t j = i; j < nodes.size(); ++j) {
            pairs.push_back({nodes[i], nodes[j]});
        }
    }
    return pairs;
}

void q1() {
    // Create adjacency list
    unordered_map<char, vector<char>> G1 = {
        {'p', {'u', 'q', 'x'}},
        {'q', {'p', 'w', 'z'}},
        {'r', {'v', 'u'}},
        {'s', {'x'}},
        {'t', {'u'}},
        {'u', {'r', 'p', 'w', 't', 'y'}},
        {'v', {'y', 'r'}},
        {'w', {'u', 'q'}},
        {'x', {'p', 's'}},
        {'y', {'v', 'u'}},
        {'z', {'q'}}
    };
    
    // Perform BFS and DFS
    bfs(G1);
    cout << endl;
    dfs(G1);
}

void q2() {
    int C, m, n;
    cin >> C >> m >> n;
    
    vector<Pair<int, int>> foodLocs;
    unordered_map<Pair<int, int>, vector<Pair<int, int>>> G2;
    
    for (int i = 0; i < m; ++i) {
        string line;
        cin >> line;
        for (int j = 0; j < n; ++j) {
            if (line[j] != 'X') {
                Pair<int, int> loc = {i, j};
                if (!G2.count(loc)) {
                    G2[loc] = {};
                }
                if (line[j] == 'F') {
                    foodLocs.push_back(loc);
                }
            }
        }
    }
    
    vector<Pair<int, int>> my_nodes;
    for (const auto& node : G2) {
        my_nodes.push_back(node.first);
    }
    
    for (const auto& combo : getPairList(my_nodes)) {
        Pair<int, int> u = combo.x;
        Pair<int, int> v = combo.y;
        if (u != v) {
            if ((v.x == u.x && abs(v.y - u.y) == 1) || (v.y == u.y && abs(v.x - u.x) == 1)) {
                G2[u].push_back(v);
                G2[v].push_back(u);
            }
        }
    }
    
    Pair<int, int> dest = {m - 1, n - 1};
    char output = dfs_q2(G2, foodLocs, C, dest) ? 'Y' : 'N';
    cout << output << endl;
}

void q3() {
    int N;
    cin >> N;
    
    vector<Pair<int, int>> interactions;
    string line;
    do {
        cin >> line;
        if (line.find(' ') == string::npos) {
            break;
        }
        int a = stoi(line.substr(0, line.find(' ')));
        int b = stoi(line.substr(line.find(' ') + 1));
        interactions.push_back({a, b});
    } while (true);
    
    int seed = stoi(line);
    int query;
    cin >> query;
    
    size_t i = 0;
    while (i < interactions.size()) {
        if (seed == interactions[i].x || seed == interactions[i].y) {
            break;
        }
        ++i;
    }
    interactions.erase(interactions.begin(), interactions.begin() + i);
    
    unordered_map<int, vector<int>> G3;
    for (const auto& p : interactions) {
        if (!G3.count(p.x)) {
            G3[p.x] = {};
        }
        G3[p.x].push_back(p.y);
        if (!G3.count(p.y)) {
            G3[p.y] = {};
        }
        G3[p.y].push_back(p.x);
    }
    
    char output = bfs_q3(G3, query) ? 'Y' : 'N';
    cout << output << endl;
}

int main() {
    q1();
    q2();
    q3();
    return 0;
}
