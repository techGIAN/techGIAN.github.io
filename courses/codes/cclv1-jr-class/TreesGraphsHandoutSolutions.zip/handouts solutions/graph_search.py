# implemented with a Queue
def bfs(G):
    Q = []
    V = dict(zip(list(G.keys()), [False] * len(G)))

    node = list(G.keys())[0]
    Q.append(node)
    V[node] = True

    while len(Q) > 0:
        node = Q.pop(0)
        print(node, end=' ')

        for nbr in G[node]:
            if not V[nbr]:
                V[nbr] = True
                Q.append(nbr)

# implemented with a Stack
def dfs(G):
    S = []
    V = dict(zip(list(G.keys()), [False] * len(G)))

    node = list(G.keys())[0]
    S.append(node)
    while len(S) > 0:
        node = S.pop(-1)
        if not V[node]:
            V[node] = True
            print(node, end=' ')
            for nbr in G[node]:
                if not V[nbr]:
                    S.append(nbr)

# DFS slightly modified to accommodate requirments of Q2
def dfs_q2(G, food_locs, C, dest_loc):
    V = dict(zip(list(G.keys()), [False] * len(G)))
    S = []

    # keep track of how many food have been collected
    # and also if the destination is reachable
    num_of_food_obtained = 0
    dest_reached = False

    node = (0,0)            # always start at (0,0)
    S.append(node)
    while len(S) > 0:
        node = S.pop(-1)
        if not V[node]:
            V[node] = True

            # keep track of how much food collected and if the destination has been reached
            if node in food_locs:
                num_of_food_obtained += 1
            if node == dest_loc:
                dest_reached = True

            for nbr in G[node]:
                if not V[nbr]:
                    S.append(nbr)

    return num_of_food_obtained >= C and dest_reached

def get_pairs(L):
    pairs = []
    for l1 in L:
        for l2 in L:
            pairs.append((l1, l2))
    return pairs

# BFS slightly modified to accommodate requirments of Q3
def bfs_q3(G, q):
    Q = []
    V = dict(zip(list(G.keys()), [False] * len(G)))

    node = list(G.keys())[0]
    Q.append(node)
    V[node] = True


    while len(Q) > 0:
        node = Q.pop(0)

        for nbr in G[node]:
            if not V[nbr]:
                V[nbr] = True
                Q.append(nbr)


    return False if q not in V else V[q]

def q1():
    G1 = {
        'p': ['u', 'q', 'x'],
        'q': ['p', 'w', 'z'],
        'r': ['v', 'u'],
        's': ['x'],
        't': ['u'],
        'u': ['r', 'p', 'w', 't', 'y'],
        'v': ['y', 'r'],
        'w': ['q', 'u'],
        'x': ['p', 's'],
        'y': ['v', 'u'],
        'z': ['q']
    }

    # comment/uncomment what you want
    dfs(G1)
    bfs(G1)

def q2():
    C = int(input())    # amount of food required
    m = int(input())    # rows
    n = int(input())    # cols

    food_loc = []
    G2 = dict()
    for i in range(m):
        line = input()
        for j in range(n):
            if line[j] != 'X':
                loc = (i, j)
                if loc not in G2:
                    G2[loc] = []
                if line[j] == 'F':
                    food_loc.append(loc)

    nodes = list(G2.keys())
    for u, v in get_pairs(nodes):
        if u != v:
            if v[1] == u[1] and abs(v[0] - u[0]) == 1 or v[0] == u[0] and abs(v[1] - u[1]) == 1:
                G2[u].append(v)
                G2[v].append(u)

    # remove duplicates in the adj list:
    for node in G2.keys():
        val = list(set(G2[node]))
        G2[node] = val

    output = 'Y' if dfs_q2(G2, food_loc, C, (m-1, n-1)) else 'N'
    print(output)

def q3():
    N = int(input())            # unused

    # store first all interactions
    # and all givens
    interactions = []
    while True:
        line = input()
        if ' ' not in line:
            break
        interaction = tuple(map(int, line.split()))
        interactions.append(interaction)

    seed = int(line)
    query = int(input())

    # build the graph
    for i in range(len(interactions)):
        if seed in interactions[i]:
            break

    interactions = interactions[i:]
    G3 = dict()
    for interaction in interactions:
        a, b = interaction
        if a not in G3:
            G3[a] = []
        G3[a].append(b)

        if b not in G3:
            G3[b] = []
        G3[b].append(a)

    # if node can be visited, return True
    # if node cannot be visited or does not exist in the interaction/infection graph, return False
    output = 'Y' if bfs_q3(G3, query) else 'N'
    print(output)

q1()
q2()
q3()