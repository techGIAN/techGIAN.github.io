#include <iostream>
#include <vector>
#include <unordered_map>
#include <unordered_set>
#include <algorithm>
using namespace std;

// Function to create the graph
unordered_map<string, vector<string>> createGraph() {
    unordered_map<string, vector<string>> adjList;
    adjList["A"] = {"B", "C"};
    adjList["B"] = {"A", "D"};
    adjList["C"] = {"A", "D"};
    adjList["D"] = {"B", "C", "E", "F"};
    adjList["E"] = {"D", "F"};
    adjList["F"] = {"D", "E"};
    return adjList;
}

// Function to find paths of length two
vector<vector<string>> pathsOfLengthTwo(const unordered_map<string, vector<string>>& G) {
    vector<vector<string>> paths;
    unordered_set<string> visited;

    for (const auto& [node, neighbors] : G) {
        for (const auto& nbr : neighbors) {
            for (const auto& nbrNbr : G.at(nbr)) {
                if (node == nbrNbr || visited.count(nbrNbr)) {
                    continue;
                }
                vector<string> path = {node, nbr, nbrNbr};
                vector<string> reversedPath = {nbrNbr, nbr, node};
                if (find(paths.begin(), paths.end(), path) == paths.end() && 
                    find(paths.begin(), paths.end(), reversedPath) == paths.end()) {
                    paths.push_back(path);
                }
            }
        }
        visited.insert(node);
    }
    return paths;
}

int main() {
    unordered_map<string, vector<string>> G = createGraph();
    vector<vector<string>> paths = pathsOfLengthTwo(G);
    for (const auto& path : paths) {
        cout << '[';
        for (size_t i = 0; i < path.size(); ++i) {
            cout << path[i];
            if (i != path.size() - 1) {
                cout << ", ";
            }
        }
        cout << ']';
        cout << endl;
    }
    return 0;
}
