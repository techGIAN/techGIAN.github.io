def create_graph():
    adj_list = {
        'A': ['B', 'C'],
        'B': ['A', 'D'],
        'C': ['A', 'D'],
        'D': ['B', 'C', 'E', 'F'],
        'E': ['D', 'F'],
        'F': ['D', 'E']
    }

    return adj_list

def paths_of_length_two(G):
    paths = []
    for node in G.keys():
        for nbr in G[node]:
            for nbr_nbr in G[nbr]:
                if node == nbr_nbr:
                    continue
                path = (node, nbr, nbr_nbr)
                reversed_path = (nbr_nbr, nbr, node)
                if path not in paths and reversed_path not in paths:
                    paths.append(path)
    return paths

def main():
    G = create_graph()
    paths = paths_of_length_two(G)
    print(paths)

if __name__ == "__main__":
    main()