#include <iostream>
#include <vector>
#include <string>
#include <queue>
#include <algorithm>
using namespace std;

// TreeNode structure
struct TreeNode {
    string value;
    TreeNode* left;
    TreeNode* right;

    TreeNode(string val) : value(val), left(nullptr), right(nullptr) {}
};

// Pair structure
template <typename K, typename V>
struct Pair {
    K key;
    V value;

    Pair(K k, V v) : key(k), value(v) {}
};

// Function to create the tree
TreeNode* createTree() {
    // Create nodes
    TreeNode* root = new TreeNode("R");
    TreeNode* a = new TreeNode("A");
    TreeNode* b = new TreeNode("B");
    TreeNode* w = new TreeNode("W");
    TreeNode* d = new TreeNode("D");
    TreeNode* m = new TreeNode("M");
    TreeNode* z = new TreeNode("Z");
    TreeNode* c = new TreeNode("C");
    TreeNode* x = new TreeNode("X");
    TreeNode* y = new TreeNode("Y");
    TreeNode* l = new TreeNode("L");
    TreeNode* e = new TreeNode("E");
    TreeNode* n = new TreeNode("N");

    // Connect nodes
    root->left = a;
    root->right = b;
    a->left = w;
    a->right = d;
    b->right = m;
    w->left = z;
    d->left = c;
    m->left = x;
    m->right = y;
    c->left = l;
    c->right = e;
    x->right = n;

    return root;
}

// Function to find all paths in the tree
vector<vector<string>> findAllPaths(TreeNode* root) {
    vector<vector<string>> paths;
    if (!root) {
        return paths;
    }

    queue<Pair<TreeNode*, vector<string>>> q;
    q.push({root, {root->value}});

    while (!q.empty()) {
        auto [node, path] = q.front();
        q.pop();

        if (!node->left && !node->right) {
            paths.push_back(path);
        }

        if (node->left) {
            vector<string> newPath = path;
            newPath.push_back(node->left->value);
            q.push({node->left, newPath});
        }

        if (node->right) {
            vector<string> newPath = path;
            newPath.push_back(node->right->value);
            q.push({node->right, newPath});
        }
    }

    return paths;
}

// Function to search for a path containing a specific node value
vector<string> searchPath(const vector<vector<string>>& paths, const string& tgt) {
    vector<string> tgtPath;
    for (const auto& path : paths) {
        if (find(path.begin(), path.end(), tgt) == path.end()) {
            continue;
        }

        for (int i = 0; i < path.size(); ++i) {
            if (path[i] == tgt) {
                tgtPath = vector<string>(path.begin(), path.begin() + i);
                break;
            }
        }
    }

    return tgtPath;
}

// Function to find the Lowest Common Ancestor (LCA) of two nodes in the tree
string lca(TreeNode* root, const string& n1Value, const string& n2Value) {
    vector<vector<string>> allPaths = findAllPaths(root);
    vector<string> n1Path = searchPath(allPaths, n1Value);
    vector<string> n2Path = searchPath(allPaths, n2Value);

    int i = 0;
    while (i < n1Path.size() && i < n2Path.size()) {
        if (n1Path[i] != n2Path[i]) {
            break;
        }
        i++;
    }

    return n1Path[i - 1];
}

int main() {
    TreeNode* tree = createTree();
    string LCA = lca(tree, "N", "Y");
    cout << LCA << endl;
    return 0;
}
