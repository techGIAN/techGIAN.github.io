# another way of creating tree is array-based approach
# each level l has 2**l nodes
# the children of the node in tree_nodes[i] is found in:
#   * tree_nodes[2*i] (left child)
#   * tree_nodes[2*i+1] (right child)
# tree_nodes = [
#     'R',
#     'A', 'B',
#     'W', 'D', None, 'M',
#     'Z', None, 'C', None, None, None, 'X', 'Y',
#     None, None, None, None, 'L', 'E', None, None, None, None, None, None, None, 'N', None, None
# ]

# OOP approach
class Node:
    def __init__(self, value):
        self.value = value
        self.left = None
        self.right = None

def create_tree():
    # create nodes
    root = Node('R')
    a = Node('A')
    b = Node('B')
    w = Node('W')
    d = Node('D')
    m = Node('M')
    z = Node('Z')
    c = Node('C')
    x = Node('X')
    y = Node('Y')
    l = Node('L')
    e = Node('E')
    n = Node('N')

    # connect them
    root.left = a
    root.right = b

    a.left = w
    a.right = d

    b.right = m

    w.left = z

    d.left = c

    m.left = x
    m.right = y

    c.left = l
    c.right = e

    x.right = n

    return root

def find_all_paths(root):
    if not root:
        return []

    paths = []
    queue = [(root, [root.value])]  # Initialize the queue with the root node and its path

    while queue:
        node, path = queue.pop(0)
        if not node.left and not node.right:  # Leaf node
            paths.append(path)
        if node.left:
            queue.append((node.left, path + [node.left.value]))  # Add left child to the queue with updated path
        if node.right:
            queue.append((node.right, path + [node.right.value]))  # Add right child to the queue with updated path

    return paths

def search_path(paths, tgt):
    tgt_path = []
    for path in paths:
        if tgt not in path:
            continue

        for i in range(len(path)):
            if path[i] == tgt:
                tgt_path = path[:i]

    return tgt_path

def lca(root, n1_value, n2_value):
    all_paths = find_all_paths(root)
    n1_path = search_path(all_paths, n1_value)
    n2_path = search_path(all_paths, n2_value)

    i = 0
    while i < len(n1_path) and i < len(n2_path):
        if n1_path[i] != n2_path[i]:
            break
        i += 1

    return n1_path[i-1]

def main():
    tree = create_tree()
    LCA = lca(tree, 'N', 'Y')
    print(LCA)

if __name__ == "__main__":
    main()