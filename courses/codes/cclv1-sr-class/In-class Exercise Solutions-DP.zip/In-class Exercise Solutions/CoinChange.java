import java.util.Scanner;

public class CoinChange {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int A = Integer.parseInt(scanner.nextLine());
        String[] arr = scanner.nextLine().split(" ");
        int[] C = new int[arr.length];
        for (int i = 0; i < arr.length; i++) {
            C[i] = Integer.parseInt(arr[i]);
        }
        int[][] M = new int[C.length + 1][A + 1];

        for (int i = 0; i <= C.length; i++) {
            for (int j = 0; j <= A; j++) {
                if (j == 0) {
                    M[i][j] = 0;
                } else if (i == 0) {
                    M[i][j] = Integer.MAX_VALUE;
                } else if (C[i - 1] > j) {
                    M[i][j] = M[i - 1][j];
                } else {
                    M[i][j] = Math.min(M[i - 1][j], 1 + M[i][j - C[i - 1]]);
                }
            }
        }

        System.out.println(M[C.length][A]);
        scanner.close();
    }
}
