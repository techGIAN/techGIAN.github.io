import java.util.Arrays;

public class Knapsack {

    public static int[][] fillTable(int N, int W, int[] p, int[] w) {
        int[][] A = new int[N + 1][W + 1];
        for (int i = 0; i <= N; i++) {
            Arrays.fill(A[i], 0);
        }

        for (int i = 0; i <= N; i++) {
            for (int C = 0; C <= W; C++) {
                if (i > 0 && w[i - 1] > C) {
                    A[i][C] = A[i - 1][C];
                } else if (i > 0 && w[i - 1] <= C) {
                    A[i][C] = Math.max(A[i - 1][C], p[i - 1] + A[i - 1][C - w[i - 1]]);
                }
            }
        }

        return A;
    }

    public static int knapsackSol(int N, int W, int[] p, int[] w) {
        int[][] A = fillTable(N, W, p, w);
        return A[N][W];
    }

    public static void main(String[] args) {
        int N = 3;
        int W = 4;
        int[] p = {4, 7, 5};
        int[] w = {1, 2, 2};
        System.out.println(knapsackSol(N, W, p, w));
    }
}
