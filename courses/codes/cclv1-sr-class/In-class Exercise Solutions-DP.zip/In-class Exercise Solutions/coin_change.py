
A = int(input())
C = [int(x) for x in input().split(" ")]

M = [[0 for _ in range(A + 1)] for _ in range(len(C) + 1)]

for i in range(0,len(C)+1):
    for j in range(1, A+1):
        if i == 0:
            x = float('inf')
        elif j == C[i-1]:
            x = 1
        elif j < C[i-1]:
            x = M[i-1][j]
        else:
            x = min(1 + M[i][j - C[i-1]], M[i-1][j])
        M[i][j] = x


print(M[-1][-1])