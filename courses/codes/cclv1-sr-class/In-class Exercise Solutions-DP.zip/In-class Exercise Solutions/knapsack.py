def fill_table(N, W, p, w):
    A = []
    for _ in range(N+1):
        row = []
        for _ in range(W+1):
            row.append(0)
        A.append(row)

    for i in range(N+1):
        for C in range(W+1):
            if i > 0 and w[i-1] > C:
                A[i][C] = A[i-1][C]
            elif i > 0 and w[i-1] <= C:
                A[i][C] = max(A[i-1][C], p[i-1] + A[i-1][C - w[i-1]])

    return A

def knapsack_sol(N, W, p, w):
    A = fill_table(N, W, p, w)
    return A[-1][-1]

N, W = 3, 4
p = [4,7,5]
w = [1,2,2]
print(knapsack_sol(N, W, p, w))