import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

// use these for Q4
import java.util.Set;
import java.util.HashSet;

public class HW7A {
    public static String text =
        "In Flanders fields the poppies blow\n" +
        "Between the crosses, row on row,\n" +
        "That mark our place; and in the sky\n" +
        "The larks, still bravely singing, fly\n" +
        "Scarce heard amid the guns below.\n" +
        "We are the Dead. Short days ago\n" +
        "We lived, felt dawn, saw sunset glow,\n" +
        "Loved, and were loved, and now we lie\n" +
        "In Flanders fields.\n" +
        "Take up our quarrel with the foe:\n" +
        "To you from failing hands we throw\n" +
        "The torch; be yours to hold it high.\n" +
        "If ye break faith with us who die\n" +
        "We shall not sleep, though poppies grow\n" +
        "In Flanders fields.\n";

    
    public static List<String> findAll(String pattern, String txt) {
        Pattern p = Pattern.compile(pattern, Pattern.CASE_INSENSITIVE);
        Matcher m = p.matcher(txt);

        List<String> matches = new ArrayList<>();
        while (m.find()) {
            matches.add(m.group());
        }
        return matches;
    }

    public static void main(String[] args) {
    	
    	int q = 7;
    	
        String pattern_q1 = "sky|fly|lie|high|die";
        String pattern_q2 = "row|low|foe|ago|though";
        String pattern_q3 = "\\bf\\w+";
        String pattern_q4 = "\\bf\\w+s\\b";
        String pattern_q5 = "\\w+low\\b";
        String pattern_q6 = "\\w*row|\\w*low|foe|ago|though";
        String pattern_q7 = "the\\s(\\w+)";
        
        switch(q) {
        	case 1:
	        	// Q1 - Write a program that prints out the words that rhyme with sky (ignore case)
	            System.out.println(findAll(pattern_q1, text));
	            break;
	            
        	case 2:
        		// Q2 - Write a program that counts out the words that rhyme with glow (ignore case)
	            System.out.println(findAll(pattern_q2, text).size());
	            break;
	            
        	case 3:
	        	// Q3 - Write a program that prints out the words that start with the letter f (ignore case)
	            System.out.println(findAll(pattern_q3, text));
	            break;
	            
        	case 4:
        		// Q4 - Write a program that prints out the unique words that start with f and ends with s (ignore case)
	            Set<String> ans = new HashSet<>(findAll(pattern_q4, text));
	            System.out.println(ans);
	            break;
	            
        	case 5:
	        	// Q5 - Write a program that prints out the words that end with low (ignore case)
	            System.out.println(findAll(pattern_q5, text));
	            break;
	            
        	case 6:
        		// Q6 - Write a program that prints out the words that rhyme with glow (ignore case)
	            System.out.println(findAll(pattern_q6, text));
	            break;
	            
        	case 7:
	        	// Q7 - Write a program that prints the words that follow the word the (ignore case)
	            System.out.println(findAll(pattern_q7, text));
	            break;
	        
	        default:
	        	break;
	           
        }
        
        
    }
}
