
public class MainRacer {

	public static void main(String[] args) {
		Racer r = new Racer();
        System.out.println(r.getName());
        r.refuel(20);
        r.start();
        r.drive(150);
        System.out.println(r.getFuel() + " fuel in tank.");
        r.drive(70);
        r.start();
        r.stop();
        r.drive(10);
        r.refuel(80);
        r.refuel(30);
        r.drive(10);
        r.start();
        r.start();
        r.drive(50);
        r.stop();
        r.setName("Hudson");
        System.out.println(r.getName());
	}

}
