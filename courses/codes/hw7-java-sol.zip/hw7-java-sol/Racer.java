
public class Racer {
	public String name;
    public double fuel;
    public boolean engineOn;

    public Racer() {
        this.name = "McQueen";
        this.fuel = 0;
        this.engineOn = false;
    }

    public String getName() {
        return name;
    }

    public double getFuel() {
        return fuel;
    }

    public boolean isEngineOn() {
        return engineOn;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void refuel(int volume) {
        double f = this.fuel;
        this.fuel = Math.min(this.fuel + volume, 100);
        System.out.println((this.fuel - f) + " unit of fuel added.  " + this.fuel + " fuel in tank.");
    }

    public void start() {
        if (this.engineOn) {
            System.out.println("WARNING: engine already on.");
        } else if (this.fuel == 0) {
            System.out.println("WARNING: cannot start engine.  Out of fuel.");
        } else {
            this.engineOn = true;
            System.out.println("Turning engine on.  Vroom Vroom.");
        }
    }

    public void stop() {
        if (this.engineOn) {
            this.engineOn = false;
            System.out.println("Turning engine off.");
        } else {
            System.out.println("WARNING: engine already off.");
        }
    }

    public void drive(int distance) {
        if (this.engineOn) {
            double d = Math.min(distance, this.fuel * 10);
            System.out.println("Distance travelled: " + d);
            this.fuel -= d / 10;
            if (this.fuel == 0) {
                this.engineOn = false;
                System.out.println("WARNING: engine shut off.  Out of fuel.");
            }
        } else {
            System.out.println("WARNING: engine is still off.  Cannot drive.");
        }
    }
    
    // One way of testing Racer.java is by adding the main method here, then calling Racer r = new Racer() for
    // creating a new object. But that is not typically the way we do OOP.
    // What we do instead is to create a new client program called MainRacer.java that will contain the
    // main method, and that is the right way of doing it!
//    public static void main(String[] args) {
//		Racer r = new Racer();
//        System.out.println(r.getName());
//        r.refuel(20);
//        r.start();
//        r.drive(150);
//        System.out.println(r.getFuel() + " fuel in tank.");
//        r.drive(70);
//        r.start();
//        r.stop();
//        r.drive(10);
//        r.refuel(80);
//        r.refuel(30);
//        r.drive(10);
//        r.start();
//        r.start();
//        r.drive(50);
//        r.stop();
//        r.setName("Hudson");
//        System.out.println(r.getName());
//	}
}
