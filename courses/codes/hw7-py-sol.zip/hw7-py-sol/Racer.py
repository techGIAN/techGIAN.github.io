class Racer:
    def __init__(self):
        self.name = "McQueen"
        self.fuel = 0
        self.engine_on = False

    def get_name(self):
        return self.name

    def get_fuel(self):
        return self.fuel

    def is_engine_on(self):
        return self.engine_on

    def set_name(self, name):
        self.name = name

    def refuel(self, volume):
        f = self.fuel
        self.fuel = min(self.fuel + volume, 100)
        print(self.fuel - f, "unit of fuel added. ", self.fuel, "fuel in tank.")

    def start(self):
        if self.engine_on:
            print("WARNING: engine already on.")
        elif self.fuel == 0:
            print("WARNING: cannot start engine.  Out of fuel.")
        else:
            self.engine_on = True
            print("Turning engine on.  Vroom Vroom.")

    def stop(self):
        if self.engine_on:
            self.engine_on = False
            print("Turning engine off.")
        else:
            print("WARNING: engine already off.")

    def drive(self, distance):
        if self.engine_on:
            d = min(distance, self.fuel * 10)
            print("Distance travelled:", float(d))
            self.fuel -= d / 10
            if self.fuel == 0:
                self.engine_on = False
                print("WARNING: engine shut off.  Out of fuel.")
        else:
            print("WARNING: engine is still off.  Cannot drive.")
