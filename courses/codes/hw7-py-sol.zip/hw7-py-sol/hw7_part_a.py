import re

def main():
    text = "In Flanders fields the poppies blow\
            Between the crosses, row on row,\
            That mark our place; and in the sky\
            The larks, still bravely singing, fly\
            Scarce heard amid the guns below.\
            We are the Dead. Short days ago\
            We lived, felt dawn, saw sunset glow,\
            Loved, and were loved, and now we lie\
            In Flanders fields.\
            Take up our quarrel with the foe:\
            To you from failing hands we throw\
            The torch; be yours to hold it high.\
            If ye break faith with us who die\
            We shall not sleep, though poppies grow\
            In Flanders fields."

    # q1(text)
    # q2(text)
    # q3(text)
    # q4(text)
    # q5(text)
    # q6(text)
    q7(text)

def q1(text):
    pattern = "sky|fly|lie|high|die"
    matches = re.findall(pattern, text, re.IGNORECASE)
    print(matches)

def q2(text):
    pattern = "row|low|foe|ago|though"
    matches = re.findall(pattern, text, re.IGNORECASE)
    print(len(matches))

def q3(text):
    pattern = "\\bf\\w+"
    matches = re.findall(pattern, text, re.IGNORECASE)
    print(matches)

def q4(text):
    pattern = "\\bf\\w+s\\b"
    matches = re.findall(pattern, text, re.IGNORECASE)
    print(set(matches))

def q5(text):
    pattern = "\\w+low\\b"
    matches = re.findall(pattern, text)
    print(matches)

def q6(text):
    pattern = "\\w*row|\\w*low|foe|ago|though"
    matches = re.findall(pattern, text, re.IGNORECASE)
    print(matches)

def q7(text):
    pattern = "the\\s(\\w+)"
    matches = re.findall(pattern, text, re.IGNORECASE)
    print(matches)

main()