
public class Car {
	
	int fuel;
	String brand;
	boolean headlights;
	String color;
	boolean engine;
	String licensePlate;
	static String[] FUEL_TYPES = {"Gasoline", "Diesel"};
	static int[] OCTANE_LEVELS = {87, 89, 91};
	
	public Car() {
		this.fuel = 100;
		this.brand = "Ford";
		this.headlights = false;
		this.color = "black";
		this.engine = false;
		this.licensePlate = "";
	}
	
	public Car(int fuel, String brand, boolean headlights, String color, boolean engine, String licensePlate) {
		this.fuel = fuel;
		this.brand = brand;
		this.headlights = headlights;
		this.color = color;
		this.engine = engine;
		this.licensePlate = licensePlate;
	}
	
	public int getFuel() {
		return this.fuel;
	}
	
	public String getBrand() {
		return this.brand;
	}
	
	public boolean getHeadlights() {
		return this.headlights;
	}
	
	public String getColor() {
		return this.color;
	}
	
	public boolean getEngine() {
		return this.engine;
	}
	
	public String getLicensePlate() {
		return this.licensePlate;
	}
	
	public void setFuel(int fuel) {
		this.fuel = fuel;
	}
	
	public void setBrand(String brand) {
		this.brand = brand;
	}
	
	public void switchHeadlights() {
		this.headlights = !this.headlights;
	}
	
	public void setColor(String color) {
		this.color = color;
	}
	
	public void setEngine(boolean engine) {
		this.engine = engine;
	}
	
	public void setLicensePlate(String licensePlate) {
		this.licensePlate = licensePlate;
	}
	
	public static void honk(int duration) {
		for (int i = 0; i < duration; i++) {
			System.out.println("Honk!");
		}
	}
	
}
