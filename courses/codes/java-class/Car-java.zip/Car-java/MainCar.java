
public class MainCar {

	public static void main(String[] args) {
//		System.out.println(Car.FUEL_TYPES[1]);
		System.out.println(Car.OCTANE_LEVELS[2]);
		Car.honk(5);
//		Car c = new Car();
//		System.out.println(c.getLicensePlate());
//		c.setLicensePlate("ABCD 123");
//		System.out.println(c.getLicensePlate());
//		
//		System.out.println(c.getColor());
//		c.setColor("red");
//		System.out.println(c.getColor());
//		
//		Car c2 = new Car(95, "Subaru", true, "white", true, "WXYZ 119");
//		System.out.println(c2.getBrand());
	}

}
