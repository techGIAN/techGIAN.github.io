
public class FancyPrint {

	/*
	 * This method prints a message called msg n times
	 * Parameters:
	 * msg - a String
	 * n - an integer
	 * Returns:
	 * nothing (or void)
	 */
	public static void nPrint(String msg, int n) {
		for (int i = 0; i < n; i++) {
			System.out.println(msg);
		}
	}
	
	/*
	 * This method prints a header (hdr), which is a String,
	 * as well as multiple String arguments
	 * Parameters:
	 * hdr - a String
	 * msgs - a variable number of Strings
	 * Returns:
	 * nothing (or void)
	 */
	public static void multiPrint(String hdr, String ... msgs) {
		System.out.println(hdr);
		for (String msg : msgs) {
			System.out.println("\t" + msg);
		}
	}
	
}
