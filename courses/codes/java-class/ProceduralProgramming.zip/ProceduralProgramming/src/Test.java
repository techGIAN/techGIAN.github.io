
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FancyPrint.nPrint("I love Java", 10);
		FancyPrint.multiPrint("Note:", "I love Java", "Please give me homework", "Signed Mr. Alix");
	}

}
