def nPrint(message, n=1):
    """
    Prints a message n times.
    :param message: a string
    :param n: an integer
    :return: None
    """
    for _ in range(n):
        print(message)

def multiPrint(header, *messages):
    """
    Prints any number of messages.
    :param header: a string
    :param messages: variable number of strings
    :return: None
    """
    print(header)
    for x in messages:
        print('\t' + x)

def listPrint(header, **list):
    """
    Prints a list
    :param header: a string
    :param list: variable named keywords of strings
    :return: None
    """
    print(header)
    for key, value in list.items():
        print('\t' + key + ': ' + str(value))