import FancyPrint

FancyPrint.nPrint("I love Python", 10)
FancyPrint.nPrint("But I love homework")

FancyPrint.multiPrint("Note 1:", "I love programming", "Please give me more homework", "Signed Mr. Alix")

FancyPrint.listPrint("Note 2:", message = "I love Python", signature = "Signed Mr. Alix")